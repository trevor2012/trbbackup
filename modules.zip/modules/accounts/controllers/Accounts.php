<?php
class Accounts extends MX_Controller
{

function __construct() {
parent::__construct();
$this->load->module('farmers');
}

function process($update_id){

    $this->load->module('site_security');
   $this->site_security->_make_sure_logged_in();

    $submit = $this->input->post('submit', TRUE);
    if ($submit=="Cancel") {
        redirect('accounts');
    } elseif($submit=="Submit"){
        $this->_process_status($update_id);

        $flash_msg = "Farmer samples have been completed.";
        $value = '<div class="alert alert-success" role="alert">'.$flash_msg. '</div>';
        $this->session->set_flashdata('item', $value);

        redirect('accounts');
    }

}

function _process_status($update_id){
    //delete record
    $data['payment_status'] = 1;
    $this->farmers->_update($update_id, $data);
}

function complete($update_id)
{
    if (!is_numeric($update_id)){
        redirect('site_security/not_allowed');
    }

    $this->load->module('site_security');
    $this->site_security->_make_sure_logged_in();

    $data['pageTitle'] = "Update Payment Status";
    $data['update_id'] = $update_id;
    $data['tableTitle'] = "Update Payment Status";
    $data['flash'] = $this->session->flashdata('item');
    $data['view_module'] = "accounts";
    $data['view_file'] = "completeconf";
    $this->load->module('template');
    $this->template->header($data);
    $this->template->sidebar($data);
    $this->template->footer($data);
}

function test()
{
    $update_id = $this->uri->segment(3);
    $data = $this->fetch_data_from_db($update_id);
    $data['tableTitle'] = "Farmers";
    $data['pageTitle'] = "Farmers";
    $data['view_module'] = "farmers";
    $data['view_file'] = "invoice";
    $this->load->module('template');
    //$this->template->header($data);
    $this->template->sidebar($data);
    $this->template->footer($data);
}

function progress()
{
    $update_id = $this->uri->segment(3);
    $this->load->model('farmers_m');
    $data['tableTitle'] = "Farmers";
     $data['status'] = $this->farmers_m->getStatus($update_id);
    $data['pageTitle'] = "Farmers";
    $data['view_module'] = "farmers";
    $data['view_file'] = "progress";
    $this->load->module('template');
    $this->template->header($data);
    $this->template->sidebar($data);
    $this->template->footer($data);
}

function sendmessage()
{


            $update_id = $this->uri->segment(3);
            $submit = $this->input->post('submit', TRUE);


            if($submit=="Submit"){
                //Process the form

                $this->form_validation->set_rules('tell', 'phone number', 'required');
                $this->form_validation->set_rules('message', 'message', 'required');


                if($this->form_validation->run() == TRUE) {
                $phone = $this->input->post('tell');

                $message = $this->input->post('message');

                $data = array(

                    'username'  => 'Yield',//username to be here

                    'password'  => 'xdARNvND', //password field

                    'type'      => 0,

                    'dlr'       => 1,

                    'source'    => 'Kutsaga', //message source

                    'destination'=> $phone, //recipient

                    'message'   => $this->input->post('message'), //message string

                    );

                $string = http_build_query($data);



                //echo $string; die();



                $ch = curl_init("http://api.rmlconnect.net:8080/bulksms/bulksms?");

                curl_setopt($ch, CURLOPT_POST, true);

                curl_setopt($ch, CURLOPT_POSTFIELDS, $string);

                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);



                $response = curl_exec($ch);





                curl_close($ch);

                $splittedstring=explode(",",$response);

        foreach ($splittedstring as $key => $value) {







        $log = array(


            'log'       => $value,

            'source'    => 'Kutsaga',

            'message'   => $message



            );



        $this->load->module('logs');

        $this->load->model('logs_m');

        $insert = $this->logs_m->log_add($log);
        $this->session->set_flashdata('message_sent', 'The message has been sent successfully');
        redirect('farmers');

        }

                        }
            }

    $data['update_id'] = $update_id;
    $this->load->model('farmers_m');
    $data['tableTitle'] = "Farmers";
    $data['records'] = $this->farmers_m->getContact($update_id);
    $data['pageTitle'] = "Farmers";
    $data['view_module'] = "farmers";
    $data['view_file'] = "send_notification";
    $this->load->module('template');
    $this->template->header($data);
    $this->template->sidebar($data);
    $this->template->footer($data);
}

function index()
{
    $data['query'] = $this->farmers->get('id');
    $data['tableTitle'] = "Farmers";
    $data['pageTitle'] = "Farmers";
    $data['view_module'] = "accounts";
    $data['view_file'] = "index";
    $this->load->module('template');
    $this->template->header($data);
    $this->template->sidebar($data);
    $this->template->footer($data);
}

function invoice()

{
    $update_id = $this->uri->segment(3);
    $data = $this->fetch_data_from_db($update_id);
    // Load all views as normal
    //$html = $this->load->view('invoice', $data);



    include(APPPATH."third_party/dompdf/autoload.inc.php");
    //$dompdf = Dompdf\Dompdf;

    $dompdf = new Dompdf\Dompdf();

    $html = $this->load->view('invoice', $data, true);
    // $dompdf->set_option('isHtml5ParserEnabled', true);
    // $dompdf->set_option('isRemoteEnabled', TRUE);
    $dompdf->set_paper('a4','portrait');
    $dompdf->load_html($html);
    $dompdf->render();
    $pdf = $dompdf->output();
    $dompdf->stream($pdf);
    //write_file('tmp/name.pdf', $pdf);









    // instantiate and use the dompdf class

    //$dompdf->loadHtml('hello world');
    //$dompdf->loadHtml($html);
    // (Optional) Setup the paper size and orientation
    //$dompdf->setPaper('A4', 'portrait');

    // Render the HTML as PDF
    //$dompdf->render();

    // Output the generated PDF to Browser
    //$dompdf->stream();
}

function invoice2()

{
    $update_id = $this->uri->segment(3);
    $data = $this->fetch_data_from_db($update_id);
    // Load all views as normal
    $this->load->view('invoice', $data);
    // Get output html
    $html = $this->output->get_output();

    // Load library
    $this->load->library('dompdf_gen');

    // Convert to PDF
    $this->dompdf->load_html($html);
    $this->dompdf->render();
    $this->dompdf->stream("welcome.pdf");
}
function fetch_data_from_db($update_id)
{
    $query = $this->get_where($update_id);
    foreach ($query->result() as $row) {
        $data['id'] = $row->id;
        $data['first_name'] = $row->first_name;
        $data['last_name'] = $row->last_name;
        $data['district'] = $row->district;
        $data['postal_address'] = $row->postal_address;
        $data['tell'] = $row->tell;
        $data['receipt_number'] = $row->receipt_number;
        $time = $row->receipt_number;
        //$this->load->module('timedate');
        //$data['invoice_date'] = $this->timedate->get_nice_date($time, 'mini');
        $data['invoice_date'] = $row->date_created;
        $data['type_of_diagnosis'] = $row->type_of_diagnosis;
        $data['cost_per_sample'] = $row->cost_per_sample;
        $data['number_of_samples'] = $row->number_of_samples;
        $data['email'] = $row->email;
        $data['crop'] = $row->crop;
        $data['variety'] = $row->variety;
        $data['sowing_date'] = $row->sowing_date;
        $data['other_useful_info'] = $row->other_useful_info;

        $data['status'] = $row->status;
        $data['plant_parts'] = $row->plant_parts;
        $data['symptoms'] = $row->symptoms;
        $data['distribution'] = $row->distribution;
        $data['history_of_site'] = $row->history_of_site;
        $data['other_crops'] = $row->other_crops;
        $data['record_id'] = $row->record_id;
        $record = $this->session->set_userdata('code', $row->record_id);
        $code = $this->session->userdata('code');


            }
    if (!isset($data)) {
        $data = "";
    }

    return $data;
}
function get($order_by)
{
    $this->load->model('farmers_m');
    $query = $this->farmers_m->get($order_by);
    return $query;
}

function get_with_limit($limit, $offset, $order_by)
{
    if ((!is_numeric($limit)) || (!is_numeric($offset))) {
        die('Non-numeric variable!');
    }

    $this->load->model('farmers_m');
    $query = $this->farmers_m->get_with_limit($limit, $offset, $order_by);
    return $query;
}

function get_where($id)
{
    if (!is_numeric($id)) {
        die('Non-numeric variable!');
    }

    $this->load->model('farmers_m');
    $query = $this->farmers_m->get_where($id);
    return $query;
}

function get_where_custom($col, $value)
{
    $this->load->model('farmers_m');
    $query = $this->farmers_m->get_where_custom($col, $value);
    return $query;
}

function _insert($data)
{
    $this->load->model('farmers_m');
    $this->farmers_m->_insert($data);
}

function _update($id, $data)
{
    if (!is_numeric($id)) {
        die('Non-numeric variable!');
    }

    $this->load->model('farmers_m');
    $this->farmers_m->_update($id, $data);
}

function _delete($id)
{
    if (!is_numeric($id)) {
        die('Non-numeric variable!');
    }

    $this->load->model('farmers_m');
    $this->farmers_m->_delete($id);
}

function count_where($column, $value)
{
    $this->load->model('farmers_m');
    $count = $this->farmers_m->count_where($column, $value);
    return $count;
}

function get_max()
{
    $this->load->model('farmers_m');
    $max_id = $this->farmers_m->get_max();
    return $max_id;
}

function _custom_query($mysql_query)
{
    $this->load->model('farmers_m');
    $query = $this->farmers_m->_custom_query($mysql_query);
    return $query;
}

}
