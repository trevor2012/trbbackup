
  <div class="row">
	<div class="col-md-12">
		<h1><?=$pageTitle?></h1>

<?php
if (isset($flash)){
	echo $flash;
}

 ?>
<?php
 $form_location= base_url()."accounts/process/".$update_id;

  ?>

	</div>
</div>
<div class="row mb-5">
	<div class="col-md-12">
		<div class="card">
			<div class="card-body">
				<div class="row">
					<div class="col-lg-12">
						<form method="post" action="<?=$form_location;?>">

							<div class="form-group row">
								<div class="col-sm-10">
									<button type="submit" name="submit" value="Submit" class="btn btn-success">Paid</button>
									<button type="submit" name="submit" value="Cancel" class="btn btn-danger">Cancel</button>
								</div>
							</div>
						</form>
						<br>
						<br>


					</div>
				</div>
			</div>
		</div>
	</div>
</div>
