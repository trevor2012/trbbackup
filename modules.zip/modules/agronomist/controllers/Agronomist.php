<?php
class Agronomist extends MX_Controller
{

function __construct() {
parent::__construct();
}

function submit($update_id)
{
    if(!is_numeric($update_id)){
        redirect('samples');
    }
    $submit = $this->input->post('submit', TRUE);
    $diagnosis_report = trim($this->input->post('diagnosis_report', TRUE));
    $additional_comment = trim($this->input->post('additional_comment', TRUE));

    if($submit =="Finished"){
        redirect('samples/details/'.$update_id);
    }elseif ($submit=="Submit") {
        # attempt insert

    if($diagnosis_report!=""){
        $data['record_id'] = $this->uri->segment(3);
        $data['user_id'] = $this->session->userdata('id');
        $data['diagnosis_report'] = $diagnosis_report;
        $data['additional_comment'] = $additional_comment;
        $data['status'] = 1;

        $this->_insert($data);
        $flash_msg = "Report has been successfully added";
        $value = '<div class="alert alert-success" role="alert"><strong>Success! </strong>'.$flash_msg.'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button></div>';
        $this->session->set_flashdata('item', $value);

    }
redirect('agronomist/update/'.$update_id);

    }



}
function submit_edit($update_id)
{
  $update_id = $this->uri->segment(3);
    if(!is_numeric($update_id)){
        redirect('samples');
    }
    $submit = $this->input->post('submit', TRUE);
    $diagnosis_report = trim($this->input->post('diagnosis_report', TRUE));
    $additional_comment = trim($this->input->post('additional_comment', TRUE));

    if($submit =="Finished"){
        redirect('samples/details/'.$update_id);
    }elseif ($submit=="Submit") {
        # attempt insert

    if($diagnosis_report!=""){
        $data['record_id'] = $this->uri->segment(3);
        $data['user_id'] = $this->session->userdata('id');
        $data['diagnosis_report'] = $diagnosis_report;
        $data['additional_comment'] = $additional_comment;
        $data['status'] = 1;

        $this->_update($update_id, $data);
        $flash_msg = "Report has been successfully updated";
        $value = '<div class="alert alert-success" role="alert"><strong>Success! </strong>'.$flash_msg.'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button></div>';
        $this->session->set_flashdata('item', $value);

    }
redirect('agronomist/update/'.$update_id);

    }



}

function update($update_id)
{
    $this->load->module('site_security');
    $this->site_security->_make_sure_logged_in();
    $update_id = $this->uri->segment(3);
    $data = $this->fetch_data_from_db($update_id);

    $data['query'] = $this->get_where_custom('record_id', $update_id);
    $data['num_rows'] = $data['query']->num_rows();

    $breadcrumbs_data['template'] = 'breadcrumb';
    $breadcrumbs_data['current_page_title'] = 'update/'.$update_id;
    $breadcrumbs_data['breadcrumbs_array'] = $this->_generate_breadcrumb_array($update_id);

    $data['pageTitle'] = "Agronomist Diagnosis";
    $data['flash'] = $this->session->flashdata('item');
    $data['update_id'] = $update_id;
    $data['breadcrumbs_data'] = $breadcrumbs_data;
    $data['view_module'] = "agronomist";
    $data['view_file'] = "update";
    $this->load->module('template');
    $this->template->header($data);
    $this->template->sidebar($data);
    $this->template->footer($data);
}
function edit($update_id)
{
    $this->load->module('site_security');
    $this->site_security->_make_sure_logged_in();
    $update_id = $this->uri->segment(3);
    $data = $this->fetch_data_from_db($update_id);

    $data['query'] = $this->get_where_custom('record_id', $update_id);
    $data['num_rows'] = $data['query']->num_rows();

    $breadcrumbs_data['template'] = 'breadcrumb';
    $breadcrumbs_data['current_page_title'] = 'update/'.$update_id;
    $breadcrumbs_data['breadcrumbs_array'] = $this->_generate_breadcrumb_array($update_id);

    $data['pageTitle'] = "Agronomist Diagnosis";
    $data['flash'] = $this->session->flashdata('item');
    $data['update_id'] = $update_id;
    $data['breadcrumbs_data'] = $breadcrumbs_data;
    $data['view_module'] = "agronomist";
    $data['view_file'] = "edit";
    $this->load->module('template');
    $this->template->header($data);
    $this->template->sidebar($data);
    $this->template->footer($data);
}

function _report()
{
  $update_id = $this->uri->segment(3);
  $data['query'] = $this->get_where_custom('record_id', $update_id);
  $data['num_rows'] = $data['query']->num_rows();
  // USER INFORMATION
  // $this->load->module('user_accounts');
  // $data['user_name'] = $this->user_accounts->_get_customer_name($user_id);
  $this->load->view('report', $data);
}

function _generate_breadcrumb_array($update_id)
{
    $homepage_url = base_url();
    $second_level_url = base_url('samples');
    $third_level_url = base_url('samples/details/'.$update_id);
    $breadcrumbs_array[$homepage_url] = "Home";
    $breadcrumbs_array[$second_level_url] = "samples";
    $breadcrumbs_array[$third_level_url] = "details";

    return $breadcrumbs_array;
}
function fetch_data_from_db($update_id){
            $query = $this->get_where($update_id);
            foreach ($query->result() as $row) {
                $data['record_id'] = $row->record_id;
                $data['diagnosis_report'] = $row->diagnosis_report;
                $data['additional_comment'] = $row->additional_comment;



            }

            if (!isset($data)) {
                $data = "";
            }

            return $data;
        }



function get($order_by)
{
    $this->load->model('agronomist_m');
    $query = $this->agronomist_m->get($order_by);
    return $query;
}

function get_with_limit($limit, $offset, $order_by)
{
    if ((!is_numeric($limit)) || (!is_numeric($offset))) {
        die('Non-numeric variable!');
    }

    $this->load->model('agronomist_m');
    $query = $this->agronomist_m->get_with_limit($limit, $offset, $order_by);
    return $query;
}

function get_where($id)
{
    if (!is_numeric($id)) {
        die('Non-numeric variable!');
    }

    $this->load->model('agronomist_m');
    $query = $this->agronomist_m->get_where($id);
    return $query;
}

function get_where_custom($col, $value)
{
    $this->load->model('agronomist_m');
    $query = $this->agronomist_m->get_where_custom($col, $value);
    return $query;
}

function _insert($data)
{
    $this->load->model('agronomist_m');
    $this->agronomist_m->_insert($data);
}

function _update($id, $data)
{
    if (!is_numeric($id)) {
        die('Non-numeric variable!');
    }

    $this->load->model('agronomist_m');
    $this->agronomist_m->_update($id, $data);
}

function _delete($id)
{
    if (!is_numeric($id)) {
        die('Non-numeric variable!');
    }

    $this->load->model('agronomist_m');
    $this->agronomist_m->_delete($id);
}

function count_where($column, $value)
{
    $this->load->model('agronomist_m');
    $count = $this->agronomist_m->count_where($column, $value);
    return $count;
}

function get_max()
{
    $this->load->model('agronomist_m');
    $max_id = $this->agronomist_m->get_max();
    return $max_id;
}

function _custom_query($mysql_query)
{
    $this->load->model('agronomist_m');
    $query = $this->agronomist_m->_custom_query($mysql_query);
    return $query;
}

}
