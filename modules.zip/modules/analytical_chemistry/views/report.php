<?php if($query->num_rows()>0){ ?>
<div class="card-header">ANALYTICAL CHEMISTRY RESULTS</div>
  <div class="card-body">
    <?php foreach ($query->result() as $row) {
        $diagnosis_report = $row->diagnosis_report;
        $additional_comment = $row->additional_comment;
        }
      ?>
<dl class="row">

  <dt class="col-sm-3">Diagnosis Notes</dt>
  <dd class="col-sm-9"><?=$diagnosis_report?></dd>

  <dt class="col-sm-3">Comment</dt>
  <dd class="col-sm-9"><?=$additional_comment?>
  </dd>

</dl>
</div>
<?php }
