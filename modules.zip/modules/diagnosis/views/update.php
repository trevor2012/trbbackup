
<div class="row">
	<div class="col-md-12">
		<h1><?=$pageTitle?></h1>
		<?=validation_errors("<div class='alert alert-danger alert-bordered'>",
	"<button type='button' class='close' data-dismiss='alert'><span>×</span><span class='sr-only'>Close</span></button>
</div>"); ?>
<?php
if (isset($flash)){
	echo $flash;
}

 ?>
<?php
 $form_location= base_url()."diagnosis/submit/".$update_id;

 $edit_url= base_url()."diagnosis/edit/".$update_id;

  ?>

	</div>
</div>
<div class="row mb-5">

<?php echo Modules::run('template/breadcrumb', $breadcrumbs_data); ?>
	<div class="col-md-12">
		<div class="card">
			<div class="card-body">
				<div class="row">
					<div class="col-lg-12">
						<form method="post" action="<?=$form_location;?>" enctype="multipart/form-data">
              <div class="form-group">
								<label for="exampleFormControlInput1" class="active">Diagnosis Test</label>
								<input type="text" name="diagnosis" class="form-control" id="exampleFormControlInput1" placeholder="">
							</div>
							<div class="form-group">
								<label for="exampleFormControlTextarea1" class="">Notes</label>
								<textarea class="form-control" name="notes" id="exampleFormControlTextarea1" rows="3"></textarea>
							</div>
							<div class="form-group">
								<label for="exampleFormControlTextarea1" class="">Recomendations</label>
								<textarea class="form-control" name="recommendations" id="exampleFormControlTextarea2" rows="3"></textarea>
							</div>

							<div class="form-group row">
								<div class="col-sm-10">
									<button type="submit" name="submit" value="Submit" class="btn btn-primary">Submit</button>
								</div>
							</div>
						</form>
						<br>
						<br>


					</div>
				</div>
			</div>
		</div>
	</div>


</div>

<script>
	 // Replace the <textarea id="editor1"> with a CKEditor
	 // instance, using default configuration.
	 CKEDITOR.replace( 'exampleFormControlTextarea1' );
	 CKEDITOR.replace( 'exampleFormControlTextarea2' );
</script>
