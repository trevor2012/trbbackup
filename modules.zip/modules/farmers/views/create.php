
<div class="row">
	<div class="col-md-12">
		<?=validation_errors("<div class='alert alert-danger alert-bordered'>",
	"<button type='button' class='close' data-dismiss='alert'><span>×</span><span class='sr-only'>Close</span></button>
</div>"); ?>
<?php
if (isset($flash)){
	echo $flash;
}

 ?>

	</div>
</div>
<?php $form_location = base_url()."farmers/create/".$update_id; ?>
<div class="row">
						<div class="col-md-12">
						</div>
					</div>
					<div class="row mb-5">
						<div class="col-md-12">
								<?php


							if($this->session->flashdata('message_sent')): ?>
							        <?php echo '<p class="alert alert-success">'.$this->session->flashdata('message_sent').'</p>'; ?>
							      <?php endif;



								 ?>
							<div class="card">
								<div class="card-body">
									<div class="row">
                    	<div class="col-lg-8 col-lg-offset-2 col-md-offset-3">
                    <form method="post" action="<?=$form_location?>">
                      <div class="form-group">
                        <label for="exampleInputEmail1">First Name</label>
                        <input type="text" name="first_name" value="<?=$first_name?>" class="form-control" id="" aria-describedby="" placeholder="">

                      </div>


                      <div class="form-group">
                        <label for="exampleInputPassword1">Last Name</label>
                        <input type="text" name="last_name" class="form-control" value="<?=$last_name?>" id="exampleInputPassword1" placeholder="">
                      </div>

                      <div class="form-group">
                        <label for="exampleInputPassword1">Title</label>
                        <input type="text" name="initials" class="form-control" value="<?=$initials?>" id="exampleInputPassword1" placeholder="">
                      </div>

                      <div class="form-group">
                        <label for="exampleInputPassword1">ID Number</label>
                        <input type="text" name="id_number" class="form-control" value="<?=$id_number?>" id="exampleInputPassword1" placeholder="">
                      </div>
                      <div class="form-group">
                        <label for="exampleInputPassword1">Tel Number</label>
                        <input type="text" name="tell" class="form-control" value="<?=$tell?>" id="exampleInputPassword1" placeholder="">
                      </div>
                      <div class="form-group">
                        <label for="exampleInputPassword1">Email</label>
                        <input type="email" name="email" class="form-control" value="<?=$email?>" id="exampleInputPassword1" placeholder="">
                      </div>
                      <div class="form-group">
                        <label for="exampleInputPassword1">Address</label>
                        <input type="text" name="postal_address" class="form-control" value="<?=$postal_address?>" id="exampleInputPassword1" placeholder="">
                      </div>
                      <div class="form-group">
                        <label for="exampleInputPassword1">District</label>
                        <input type="text" name="district" class="form-control" value="<?=$district?>" id="exampleInputPassword1" placeholder="">
                      </div>

                      <button type="submit" name="submit" value="Submit" class="btn btn-primary btn-gradient btn-block">

                      Update Details
                      </button>

                    </form>
                  </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
