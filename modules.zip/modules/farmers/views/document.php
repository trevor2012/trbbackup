<?php
//============================================================+
// File name   : example_003.php
// Begin       : 2008-03-04
// Last Update : 2013-05-14
//
// Description : Example 003 for TCPDF class
//               Custom Header and Footer
//
// Author: Nicola Asuni
//
// (c) Copyright:
//               Nicola Asuni
//               Tecnick.com LTD
//               www.tecnick.com
//               info@tecnick.com
//============================================================+

/**
 * Creates an example PDF TEST document using TCPDF
 * @package com.tecnick.tcpdf
 * @abstract TCPDF - Example: Custom Header and Footer
 * @author Nicola Asuni
 * @since 2008-03-04
 */

// Include the main TCPDF library (search for installation path).

$su_id = $this->uri->segment(3);
$this->load->module('farmers');
$this->load->module('user_accounts');
$technician = $this->session->userdata('firstname');
$technician_lastname = $this->session->userdata('lastname');
// $hod_name = $this->farmers->_get_user_name($su_id);
$record_id = $this->farmers->_get_record_id($su_id);

// Extend the TCPDF class to create custom Header and Footer
class MYPDF extends TCPDF {

    //Page header
    public function Header() {
        // Logo
        $this->SetY(10);
        $image_file = K_PATH_IMAGES.'logo.png';
        //$this->Image($image_file, 80, 10, 15, '', 'PNG', '', 'T', false, 300, '', false, false, 0, false, false, false);
        // Set font
        $this->SetFont('helvetica', 'B', 20);
        // Title
        //$this->Cell(0, 15, '<< TCPDF Example 003 >>', 0, false, 'C', 0, '', 0, false, 'M', 'M');
    }

    // Page footer
    public function Footer() {
        // Position at 15 mm from bottom
        $this->SetY(-28);

        // Set font
        $this->SetFont('times', '', 8);
        $footertext = "<p style='text-align:center;'>The Division comprises of the Entomology, Nematology and Pathology Skills Group. In addition, it operates a Plant Clinic as a diagnostic and advisory service to tobacco growers and merchants and other stakeholders in the agricultural and horticultural industries.</p>";
        $footertext .= "<p style='text-align:center;'>DISCLAIMER: The opinions expressed in this message do not necessarily reflect the official view of the Tobacco Research Board</p>";
        $this->writeHTML($footertext, false, true, false, true);
        // Page number
        $this->Cell(0, 10, 'Page '.$this->getAliasNumPage().'/'.$this->getAliasNbPages(), 0, false, 'C', 0, '', 0, false, 'T', 'M');
    }
}

// create new PDF document
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Kutsaga');
$pdf->SetTitle('Dignosis Report');
$pdf->SetSubject('Yearly Customer Finanacial Report');
$pdf->SetKeywords('Purchase, Sale, Order, Payment');
  // set default header data
$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' My PDF', PDF_HEADER_STRING, array(0,64,255), array(0,64,100));



// set default header data
$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE, PDF_HEADER_STRING);
// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
    require_once(dirname(__FILE__).'/lang/eng.php');
    $pdf->setLanguageArray($l);
}

// ---------------------------------------------------------

// set font
$pdf->SetFont('times', '', 10);

// add a page
$pdf->AddPage();

// writeHTML($html, $ln=true, $fill=false, $reseth=false, $cell=false, $align='')
// writeHTMLCell($w, $h, $x, $y, $html='', $border=0, $ln=0, $fill=0, $reseth=true, $align='', $autopadding=true)

// create some HTML content
foreach ($records as $row) {
  $diagnosis = $row->diagnosis_report;
  $recom = $row->additional_comment;
  $time =  $row->created_at;
  $hod_name = $this->farmers->_get_user_name($su_id);
  $technician_name = $this->user_accounts->_get_username($row->user_id);
  $title = $this->user_accounts->_get_title($row->user_id);
$html = '
<table border="" cellspacing="3" cellpadding="4">

    <tr>
        <td><br><br><br><br>TEL: (263-4) 575 289 <br>
FAX: (263-4) 575 288<br>
tobres@kutsaga.co.zw<br>
http://kutsaga.co.zw</td>
        <td bgcolor="" align="center" colspan="2">
        <img src="assets/img/logo_document.jpg" alt="test alt attribute" width="" height="" border="0"/>
        </td>
        <td><font color="#FF0000">'.$record_id.'</font><br><br><br><br>
        P.O.BOX 1909<br>
        HARARE<br>
        ZIMBABWE</td>
    </tr>

</table>
<hr>

<table border="" cellspacing="3" cellpadding="4">

    <tr>
        <td><h4> Client Details</h4><br>
        '.$hod_name.'<br>
        '.$postal_address.'<br>
        '.$district.'<br>
        '.$tell.'<br>

        </td>


        <td>
        Case #: '.$record_id.'<br>
        Date completed: '.$time.'</td>
    </tr>

</table>
<h2>DIAGNOSIS TEST RESULTS</h2>
<hr color="#a0522d">
';


// set some text to print
$html .= $diagnosis;
$html .= $recom;
$html .= '<hr>';
$html .= '
<table border="" cellspacing="3" cellpadding="4">
<tr>
<td>
<h3><br>'.$technician_name.'</h3>
Tobacco Research Board (Kutsaga)<br>
Plant Health Services Division<br>
P.O. Box 1909<br>
Harare, Zimbabwe<br>
Tel: +263 - (0)4 - 2575 289/94 - Ext 214<br>
Fax: +263 - (0)4 - 575288

</td>
  </tr>

</table>
';
$txt = <<<EOD
EOD;

// print a block of text using Write()
$pdf->Write(0, $txt, '', 0, 'C', true, 0, false, false, 0);
$pdf->writeHTML($html, true, false, true, false, '');

}
// ---------------------------------------------------------

//Close and output PDF document
$pdf->Output('Diagnosis.pdf', 'I');

//============================================================+
// END OF FILE
//============================================================+
