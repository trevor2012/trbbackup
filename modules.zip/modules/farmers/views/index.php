<div class="row">
						<div class="col-md-12">
							<h1><?php echo $tableTitle; ?></h1>
							<?php $add_page_url = base_url()."farmers/#"; ?>
						</div>
					</div>
					<div class="row mb-5">
						<div class="col-md-12">
								<?php


							if($this->session->flashdata('message_sent')): ?>
							        <?php echo '<p class="alert alert-success">'.$this->session->flashdata('message_sent').'</p>'; ?>
							      <?php endif;



								 ?>
							<div class="card">
								<div class="card-body">
									<div class="row">

										<div class="col-lg-12 pb-5">
											<h2><a href="<?=$add_page_url; ?>"><button id="btnGroupVerticalDrop2" type="button" class="btn btn-outline-success  waves-effect waves-light"  aria-haspopup="true" aria-expanded="false">
													Add Farmer Details
												</button></a></h2>

											<div class="table-responsive">
												<table id="datatable-1" class="table table-datatable table-striped table-hover">
													<thead>
														<tr>
															<th>GROWER NUMBER</th>
															<th>SAMPLE NO:</th>
						                                    <th>FIRST NAME</th>
											                <th>LASTNAME</th>
											                <th>PHONE</th>
											                <th>EMAIL</th>
											                <th>INVOICE NO:</th>

						                                    <th>ACTIONS</th>
											            </tr>
													</thead>
													<tbody>
														 <?php
														 $this->load->module('timedate');
														 foreach($query->result()  as $row) {
															$progress_url = base_url()."farmers/progress/".$row->id;
														 	$sendmessage_url = base_url()."farmers/sendmessage/".$row->id;
                              $complete_url =base_url()."farmers/complete/".$row->id;
															$edit_url =base_url()."farmers/create/".$row->id;
														 	$download_url = base_url()."farmers/report/".$row->id;
														 	$delete_page_url = base_url()."user_accounts/deleteconf/".$row->id;
														 	//$date_made = $this->timedate->get_nice_date($row->date_made, 'mini');
														 ?>
														<tr>
															<td><?php echo $row->growers_number; ?></td>
															<td><?php echo $row->record_id; ?></td>
															<td><?php echo $row->first_name; ?></td>
															<td><?php echo $row->last_name; ?></td>
						                                    <td><?php echo $row->tell; ?></td>
															<td><?php echo $row->email; ?></td>
															<td><?php echo $row->receipt_number; ?> </td>

															<td>

																<div class="btn-group">
																	<button class="btn btn-primary btn-sm dropdown-toggle waves-effect waves-light" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
																		Actions
																	</button>
																	<div class="dropdown-menu" x-placement="top-start" style="position: absolute; transform: translate3d(0px, -2px, 0px); top: 0px; left: 0px; will-change: transform;">
																		<a class="dropdown-item" href="<?=$progress_url?>">View</a>
																		<a class="dropdown-item" href="<?=$edit_url?>">Edit Farmer Details</a>
																		<a class="dropdown-item" href="<?=$complete_url?>">Mark as Complete</a>
																		<a class="dropdown-item" href="<?=$sendmessage_url?>">Send Message</a>
																		<a class="dropdown-item" target="_blank" href="<?=$download_url?>">Download Report</a>
																	</div>
																</div>
															</td>
														</tr>
													 <?php } ; ?>
													</tbody>
												</table>
											</div>
										</div>


									</div>
								</div>
							</div>
						</div>
					</div>

						<!-- Modal -->
			<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<div class="modal-body">
							...
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
							<button type="button" class="btn btn-primary">Save changes</button>
						</div>
					</div>
				</div>
			</div>
