<?php

$logo = 'assets/img/home.jpg';

 ?>


<p style="text-align: center;"><img src="<?=$logo?>" width="140" height="70"></p>
<p style="text-align: center;"><b>TOBACCO RESEARCH BOARD</b> <br>KUTSAGA RESEARCH STATION <br> AIRPORT RING ROAD, HARARE</p>

 <table width="100%" cellpadding="5">
       <tr>
        <td width="65%">
         <p>TELEPHONE: (263-4) 575 289 <br>TELEFAX: (263-4) 575 288 <br>EMAIL: tobres@kutsaga.co.zw <br>WEBSITE: http://wwww.kutsaga.co.zw </p>
        </td>
        <td width="35%">
        <p>P.O.BOX 1909 <br>HARARE <br>ZIMBABWE</p>
        </td>
       </tr>
      </table>


   <table width="100%" border="1" cellpadding="5" cellspacing="0">
    <tr>
     <td colspan="2" align="center" style="font-size:18px"><b>TAX INVOICE</b><br>PLANT CLINIC - PLANT PATHOLOGY</td>

    </tr>
    <tr>
     <td colspan="2">
      <table width="100%" cellpadding="5">
       <tr>
        <td width="65%">
         To,<br />
         <b>RECEIVER (BILL TO)</b><br/>
         Name : <?=$first_name .' '. $last_name?>  <br />
         Billing Address : <?=$postal_address?><br /><?=$district?>
        </td>
        <td width="35%">
         Invoice No. :<?=$receipt_number?>  <br />
         Invoice Date :<?=$invoice_date?> <br />
         VAT REG NO : 1000308 <br />
         Telephone :<?=$tell?> <br />
        </td>
       </tr>
      </table>
      <br />
      <table width="100%" border="1" cellpadding="5" cellspacing="0">
       <tr>
        <th width="10%">Sr No.</th>
        <th width="40%">Service Requested</th>
        <th width="15%">N0: of Samples</th>
        <th width="25%">Total Cost</th>
       </tr>
       <tr>
        <th width="10%">1</th>
        <th width="60%"><?=$type_of_diagnosis?></th>
        <th width="15%"><?=$number_of_samples?></th>
        <th width="25%">$<?=$cost_per_sample?></th>

       </tr>
     </table>


     <table width="100%" border="1" cellpadding="5" cellspacing="0">
        <tr>
          <?php
            $total = $cost_per_sample*$number_of_samples;


           ?>
         <td width="80%" align="right" colspan="11"><b>Total</b></td>
         <td width="20%" align="right"><b>$<?=$total?></b></td>
        </tr>
        <tr>
         <td colspan="11"><b>Total Amt. Before Tax :</b></td>
         <td align="right">$<?=$total?></td>
        </tr>
        <?php
        $vat = $total*0.15;
        $grant_total = $total+$vat;
        $vat_total =$total = number_format($vat, 2);
        $grant_total_final = number_format($grant_total, 2);

         ?>

        <tr>
         <td colspan="11">VAT AMOUNT (15%) :</td>
         <td align="right">$<?=$vat_total?></td>
        </tr>
        <tr>
         <td colspan="11"><b>Total Amt. incl VAT :</b></td>
         <td align="right"><b>$<?=$grant_total_final?></b></td>
        </tr>


      </table>
     </td>
    </tr>
   </table>
