
<div class="row">
	<div class="col-md-12">
		<h1><?php echo $tableTitle; ?></h1>
		<?php $add_page_url = base_url()."user_accounts/create"; ?>
	</div>
</div>
<div class="row mb-5">
	<?php echo Modules::run('template/breadcrumb', $breadcrumbs_data); ?>
	
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<ul class="nav nav-tabs card-header-tabs" id="myTab-6" role="tablist">
										<li class="nav-item waves-effect waves-light">
											<a class="nav-link active show" href="#tab-6-1" data-toggle="tab" role="tab" aria-controls="tab-6-1" aria-selected="true">Details</a>
										</li>
										<li class="nav-item waves-effect waves-light">
											<a class="nav-link" href="#tab-6-2" data-toggle="tab" role="tab" aria-controls="tab-6-2" aria-selected="false">Progress</a>
										</li>
									</ul>
								</div>
								<div class="card-body">
									<div class="tab-content" id="myTabContent-6">
										<div id="tab-6-1" class="tab-pane fade active show" role="tabpanel" aria-labelledby="tab-6-1">
											<?php echo Modules::run('samples/_draw_details'); ?>
										</div>
										<div id="tab-6-2" class="tab-pane fade" role="tabpanel" aria-labelledby="tab-6-2">

										</div>
										<div id="tab-6-3" class="tab-pane fade" role="tabpanel" aria-labelledby="tab-6-3">
											<h4 class="card-title">Tab 3 - Special title treatment</h4>
											<p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
											<a href="#" class="btn btn-primary waves-effect waves-light">Go somewhere</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
