
<div class="row">
	<div class="col-md-12">
		<h1><?=$pageTitle?></h1>
		<?=validation_errors("<div class='alert alert-danger alert-bordered'>",
	"<button type='button' class='close' data-dismiss='alert'><span>×</span><span class='sr-only'>Close</span></button>
</div>"); ?>
<?php
if (isset($flash)){
	echo $flash;
}

 ?>
<?php
 $form_location= base_url()."farmers/sendmessage/".$update_id;
 $su_id = $this->uri->segment(3);
 $this->load->module('farmers');
 $phone = $this->farmers->_get_mobile_number($su_id);
 $name = $this->farmers->_get_user_name($su_id);
// foreach ($records as $record) {
//     $name = $record->last_name;
//     $initial = $record->initials;
//     $diagnosis = $record->type_of_diagnosis;
// 		$phone = $record->tell;
// }
$message = "Dear $name, Your results for $diagnosis are ready. Please contact us to obtain them.";
  ?>

	</div>
</div>
<div class="row mb-5">
	<div class="col-md-12">
		<div class="card">
			<div class="card-body">
				<div class="row">
					<div class="col-lg-12">
						<form method="post" action="<?=$form_location;?>">
							<div class="form-group">
								<label for="exampleFormControlTextarea1" class="">Phone Number</label>
									<input type="text" name="tell" class="form-control" value="<?=$phone?>" id="" placeholder="">
									<span style="color:red;"><small>*****Note phone number should be in this format <strong>263772000000</strong>*****</small>	</span>
							</div>
							<div class="form-group">
								<label for="exampleFormControlTextarea1" class="">Message</label>
								<textarea class="form-control" name="message" id="text" rows="3"><?=$message?></textarea>
								<div id="result"></div>
							</div>

							<div class="form-group row">
								<div class="col-sm-10">
									<button type="submit" name="submit" value="Submit" class="btn btn-primary">Submit</button>
								</div>
							</div>
						</form>
						<br>
						<br>


					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
//word count

function wordCount( val ){
	var wom = val.match(/\S+/g);
	return {
			charactersNoSpaces : val.replace(/\s+/g, '').length,
			characters         : val.length,
			words              : wom ? wom.length : 0,
			lines              : val.split(/\r*\n/).length
	};
}


var textarea = document.getElementById("text");
var result   = document.getElementById("result");

textarea.addEventListener("input", function(){
var v = wordCount( this.value );
result.innerHTML = (
		// "<br>Characters (no spaces):  "+ v.charactersNoSpaces +
		"<br>Characters (and spaces): "+ v.characters
		// "<br>Words: "+ v.words +
		// "<br>Lines: "+ v.lines
);
}, false);
</script>
