<div class="row mb-5">
	<div class="col-md-12">
		<div class="card">
			<div class="card-body">
				<div class="row">

					<div class="col-lg-12 pb-5">


						<?php foreach ($status as $progress) {

							$pathology_status = $progress->pathology_status;
							$entomology_status = $progress->entomology_status;
							$nematology_status = $progress->nematology_status;
							$agronomy_status = $progress->agronomy_status;


							$total_status = $pathology_status+$entomology_status+$nematology_status+$agronomy_status;

						?>

						<div class="progress">
							<div class="progress-bar" role="progressbar" style="width: <?=$total_status?>%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><?=$total_status?>%</div>
						</div>

						<?php } ?>

							</div>


						</div>
					</div>
				</div>
			</div>
		</div>
