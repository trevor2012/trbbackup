<?php

class Home extends MX_Controller
{
  function __construct()
  {
    parent::__construct();
        $this->load->model('home_m');
       // $this->form_validation->CI =& $this;
  }
    function _draw_admissions()
    {
        $this->load->view('admissions_menu');
    }




  function index()
  {
    $data['pageTitle'] = "";
        $data['username'] =$this->input->post('username', TRUE);
      $data['view_module'] = "home";
      $data['view_file'] = "homepage";
      $this->load->module('template');
      $this->template->login_header($data);
      $this->template->login_footer($data);
  }
function logout(){
  unset($_SESSION['user_id']);
  $this->load->module('site_cookies');
  $this->site_cookies->_destroy_cookie();
  redirect(base_url());
}

function dashboard()
{
    $this->load->module('site_security');
    $this->site_security->_make_sure_logged_in();
    $data['pageTitle'] = "My Account";
    $data['flash'] = $this->session->flashdata('item');
    $data['view_module'] = "home";
    $data['view_file'] = "dashboard";
    $this->load->module('template');
    $this->template->header($data);
    $this->template->sidebar($data);
    $this->template->footer($data);

}

/****************************************
NEW LOGIN METHOD
******************************************/

public function login()

{

    $this->form_validation->set_rules('username', 'Username', 'required');

    $this->form_validation->set_rules('pword', 'Password', 'required');



    if($this->form_validation->run() == FALSE) {

      $data['username'] = "";
      $data['view_module'] = "home";
      $data['view_file'] = "homepage";
      $this->load->module('template');
      $this->template->login_header($data);
      $this->template->login_footer($data);

    }else{



        $post = $this->input->post();

        $clean = $this->security->xss_clean($post);


        $this->load->module('user_accounts');
        $this->load->model('user_accounts_m');

        $userInfo = $this->user_accounts_m->checkLogin($clean);



        if(!$userInfo){

            $this->session->set_flashdata('flash_message', 'The login was unsucessful');

            redirect(site_url().'home');

        }

        foreach($userInfo as $key=>$val){

            $this->session->set_userdata($key, $val);

        }

        if($this->session->userdata['role']=='accounts'){
          redirect('accounts');
        }
        if($this->session->userdata['role']=='admin'){
          redirect('samples');
        } else {
          redirect('samples');
        }

    }



}







public function login_old(){
            $data['title'] = 'Sign In';

            $this->form_validation->set_rules('username', 'username', 'required');
            $this->form_validation->set_rules('pword', 'password', 'required');

            if($this->form_validation->run() === FALSE){
                $data['username'] = "";
                $data['view_module'] = "home";
                $data['view_file'] = "homepage";
                $this->load->module('template');
                $this->template->login_header($data);
                $this->template->login_footer($data);
            } else {

                // Get username
                $username = $this->input->post('username');
                // Get and encrypt the password
                //$pword = md5($this->input->post('pword'));
                // Get and encrypt the password
                $password = md5($this->input->post('pword'));

                // Login user
                $this->load->module('user_accounts');
                $this->load->model('user_accounts_m');
                $user_id = $this->user_accounts_m->login($username, $password);


                if($user_id){
                    // Create session
                    // $user_data = array(
                    //     'id' => $user_id,
                    //     'username' => $username,
                    //     'role' => $row->role,
                    //     'logged_in' => true
                    // );
                    foreach($user_data as $key=>$val){
                  $this->load->library('session');

                   $this->session->set_userdata($key, $val);

                    }




                    $this->session->set_userdata($user_data);

                    // Set message
                    $this->session->set_flashdata('user_loggedin', 'You are now logged in');

                   redirect('samples');

                } else {
                    // Set message
                    $this->session->set_flashdata('login_failed', 'Login is invalid');

                    redirect('/');
                }
            }
        }

function submit_login()
{
      $submit = $this->input->post('submit', TRUE);

            if($submit=="Submit"){

                //Process the form

                $this->form_validation->set_rules('username', 'Username', 'required|min_length[5] |max_length[50]|callback_username_check');
                $this->form_validation->set_rules('pword', 'Password', 'required|min_length[7] |max_length[35]');


                if($this->form_validation->run() == TRUE) {
                    //get the variables from post
                    //figure out the id

                    $col1 = 'username';
                    $value1 = $this->input->post('username', TRUE);
                    $col2 = 'email';
                    $value2 = $this->input->post('username', TRUE);

                    $query = $this->user_accounts->get_with_double_condition($col1, $value1, $col2, $value2);

                      foreach ($query->result() as $row) {
                        $user_id = $row->id;
                      }
                      $remember = $this->input->post('remember', TRUE);
                      if($remember=="remember-me") {
                        $login_type = "longterm";
                      } else {
                        $login_type = "shortterm";
                      }

                    //send the clients to the private area
                 	 redirect('dashboard');


                }
                $data['username'] = "";
                $data['view_module'] = "home";
                $this->load->module('template');
                $this->template->login_header($data);
                $this->template->login_footer($data);


                }
  }

function _in_you_go($user_id){
  //NB: login time can be long term or short term

if($this->session->userdata['role']=='accounts'){
  redirect('accounts');
}
  //send user to the private page
  redirect('dashboard');
}

function submit()
{
            $submit = $this->input->post('submit', TRUE);

            if($submit=="Submit"){

                //Process the form


                $this->form_validation->set_rules('username', 'Username', 'required|min_length[5] |max_length[50]|is_unique[user_accounts.username]');
                $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
                $this->form_validation->set_rules('pword', 'Password', 'required|min_length[7] |max_length[35]');
                $this->form_validation->set_rules('repeat_pword', 'Repeat Password', 'required|matches[pword]');


                if($this->form_validation->run() == TRUE) {
                    //get the variables from post

                    $this->_process_create_account();
                    redirect('user/register');
                    echo "Account Created successfully. Please Login";

                    die();


                   } else {
                     $this->register();

                   }
                }
  }

function _process_create_account(){
    $this->load->module('user_accounts');
    $data = $this->fetch_data_from_post();
    unset($data['repeat_pword']);

    $pword = $data['pword'];
    $this->load->module('site_security');
    $data['pword'] = $this->site_security->_hash_string($pword);
    $this->user_accounts->_insert($data);

}
function register()
{
    $data = $this->fetch_data_from_post();
    $data['flash'] = $this->session->flashdata('item');
    $data['view_module'] = "user";
    $data['view_file'] = "start";
    $this->load->module('template');
    $this->template->public_header($data);
}

function fetch_data_from_post()
{
    $data['username'] = $this->input->post('username', TRUE);
    $data['email'] = $this->input->post('email', TRUE);
    $data['pword'] = $this->input->post('pword', TRUE);
    $data['repeat_pword'] = $this->input->post('repeat_pword', TRUE);
    return $data;
}

function fetch_data_from_db()
{
    $data['username'] = $row->username;
    $data['email'] = $row->email;
    $data['pword'] = $row->pword;
    $data['repeat_pword'] = $row->repeat_pword;
    return $data;
}

function item_check($str)
{
  $item_url = Url_title($str);
  $mysql_query = "select * from store_items wheere item_title='$str' and item_url='$item_url'";

  $update_id = $this->uri->segment(3);
  if(is_numeric($update_id)){
    $msql_query.="and id!=$update_id";
  }

  $query = $this->_custom_query($mysql_query);
  $num_rows = $query->num_rows();

  if($num_rows>0){
    $this->form_validation->set_message('item_check', 'Custom message here');
    return FALSE;
  }

  else{
    return TRUE;
  }
}


function username_check($str)
{

$this->load->module('user_accounts');
$this->load->module('site_security');

$error_msg = "You did not enter a correct username or password";

$col1 = 'username';
$value1 = $str;
$col2 = 'email';
$value2 = $str;

$query = $this->user_accounts->get_with_double_condition($col1, $value1, $col2, $value2);
$num_rows = $query->num_rows();


  if($num_rows<1){
    $this->form_validation->set_message('username_check', $error_msg);
    return FALSE;
  }

  foreach($query->result() as $row) {
    $pword_on_table = $row->pword;
  }

    $pword = $this->input->post('pword', TRUE);
    $result = $this->site_security->_verify_hash($pword, $pword_on_table);

    if($result==TRUE){
      return TRUE;
    } else {
      $this->form_validation->set_message('username_check', $error_msg);
      return FALSE;
    }
}




}






 ?>
