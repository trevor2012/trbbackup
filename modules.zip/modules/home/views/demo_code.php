if($this->session->userdata['role'] == 'admin'){ ?>
            
     } 