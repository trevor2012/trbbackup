<div class="main-content">

					<!-- NAV TABS -->
					<ul class="nav nav-tabs nav-tabs-custom-colored tabs-iconized">
						
					</ul>
					<!-- END NAV TABS -->
					<div class="tab-content profile-page">
						<!-- PROFILE TAB CONTENT -->
						<div class="tab-pane profile active" id="profile-tab">
							<div class="row">
								<div class="col-md-3">
									<div class="user-info-right">
					
										<div class="contact_info">
											<h3><i class="fa fa-square"></i> Checklist Information </h3>
											<p class="data-row">
												<span class="data-name">Supervisor</span>
												<span class="data-value"><?=$item?></span>
											</p>
											<p class="data-row">
												<span class="data-name">Mechandiser</span>
												<span class="data-value"><?=$item?></span>
											</p>
											<p class="data-row">
												<span class="data-name">Shop Name</span>
												<span class="data-value"><?=$item?></span>
											</p>
										</div>
									
									</div>
								</div>
								<div class="col-md-9">
									<div class="user-info-right">
										<div class="basic-info">
											<h3><i class="fa fa-square"></i>Checklist Details</h3>
											<p class="data-row">
												<span class="data-name" style="width:30em;">Username</span>
												<span class="data-value"><?=$item?></span>
											</p>
											<p class="data-row">
												<span class="data-name" style="width:30em;">Birth Date</span>
												<span class="data-value"><?=$item?></span>
											</p>
											<p class="data-row">
												<span class="data-name" style="width:30em;">Gender</span>
												<span class="data-value"><?=$item?></span>
											</p>
											<p class="data-row">
												<span class="data-name" style="width:30em;">Website</span>
												<span class="data-value"><?=$item?></span>
											</p>
											<p class="data-row">
												<span class="data-name" style="width:30em;">Last Login</span>
												<span class="data-value"><?=$item?></span>
											</p>
											<p class="data-row">
												<span class="data-name" style="width:30em;">Call Register Photo</span>
												<span class="data-value">
													

														<div class="thumbnail">
															<img class="" src="<?=$image_url?>" alt="" />
														</div>
											
												</span>
											</p>

											<p class="data-row">
												<span class="data-name" style="width:30em;">Check Notebook</span>
												<span class="data-value"><?=$item?></span>
											</p>
											 <p class="data-row">
												<span class="data-name" style="width:30em;">Check Uniform</span>
												<span class="data-value"><?=$item?></span>
											</p>
											<p class="data-row">
												<span class="data-name" style="width:30em;">Check Stock Card</span>
												<span class="data-value"><?=$item?></span>
											</p>
											<p class="data-row">
												<span class="data-name" style="width:30em;">Check Promotional Lines</span>
												<span class="data-value"><?=$item?></span>
											</p>
											<p class="data-row">
												<span class="data-name" style="width:30em;">Check Expiries</span>
												<span class="data-value"><?=$item?></span>
											</p>
											<p class="data-row">
												<span class="data-name" style="width:30em;">Check Line Pricing</span>
												<span class="data-value"><?=$item?></span>
											</p>
										</div>
								
										<div class="about">
											<h3><i class="fa fa-square"></i> Comment</h3>
											<p>Dramatically facilitate proactive solutions whereas professional intellectual capital. Holisticly utilize competitive e-markets through intermandated meta-services. Objectively.</p>
											<p>Monotonectally foster future-proof infomediaries before principle-centered interfaces. Assertively recaptiualize cutting-edge web services rather than emerging "outside the box" thinking. Phosfluorescently cultivate resource maximizing technologies and user-centric convergence. Completely underwhelm cross functional innovation vis-a-vis.</p>
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- END PROFILE TAB CONTENT -->
						
					</div>
				</div>