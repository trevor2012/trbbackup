<?php
	$form_location = base_url().'login';
?>
<style media="screen">
.center {
	display: block;
	margin-left: auto;
	margin-right: auto;
	width: 50%;
}
</style>
	<div class="container-fluid">
		<div class="row">
			<div class="right-column sisu">
				<div class="row mx-0">
					<div class="col-md-7 order-md-2 signin-right-column px-5 bg-dark" data-qp-bg-image="kutsaga.jpg">
						<a class="signin-logo d-sm-block d-md-none"  href="#">
							<img src="assets/img/home.png" width="140" height="70" class="center" alt="TRB">
						</a>
						<h1 class="display-4">KUTSAGA PATHOLOGY CLINIC</h1>

					</div>
					<div class="col-md-5 order-md-1 signin-left-column bg-white px-5">
						 <?php if($this->session->flashdata('login_failed')): ?>
					        <?php echo '<p class="alert alert-danger">'.$this->session->flashdata('login_failed').'</p>'; ?>
					      <?php endif; ?>

					      <?php if($this->session->flashdata('user_loggedin')): ?>
					        <?php echo '<p class="alert alert-success">'.$this->session->flashdata('user_loggedin').'</p>'; ?>
					      <?php endif; ?>


						<?php echo validation_errors("<div class='alert alert-danger alert-dismissible' role='alert'>
								<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button>", "</div>"); ?>
						<a class="signin-logo d-sm-none d-md-block" href="#">
							<img src="assets/img/home.png" width="140" height="70" class="center" alt="TRB">
						</a>
						<form method="post" action="<?=$form_location?>">
							<div class="form-group">
								<label for="exampleInputEmail1">Email address/ Username</label>
								<input type="text" name="username" value="<?=$username?>" class="form-control" id="" aria-describedby="" placeholder="Enter username or email">
								<small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
							</div>
							<div class="form-group">
								<label for="exampleInputPassword1">Password</label>
								<input type="password" name="pword" class="form-control" id="exampleInputPassword1" placeholder="Password">
							</div>
							<div class="custom-control custom-checkbox mb-3">
								<input type="checkbox" class="custom-control-input" id="keep-signed-in">
								<label class="custom-control-label" for="keep-signed-in">Keep Me Signed In</label>
							</div>
							<button type="submit" value="Submit" class="btn btn-primary btn-gradient btn-block">
								<i class="batch-icon batch-icon-key"></i>
								Sign In
							</button>

						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
