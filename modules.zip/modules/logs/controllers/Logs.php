<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Logs extends MX_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	 public function __construct()
	 	{
	 		parent::__construct();
			$this->load->helper('url');
	 		$this->load->model('logs_m');
	 	}


	public function all(){
		$data['query']=$this->contacts_m->get_all_contacts();
		echo json_encode($data);
	}

	public function index()
	{
		  //$this->output->enable_profiler(TRUE);
		  $data['contacts']=$this->contacts_m->get_all_contacts();
		  $data['view_module'] = "contacts";
		  $data['pageTitle'] = "Contacts";
		  $data['tableTitle'] = "Contacts";
		  $data['view_file'] = 'contact_view';
		  $this->load->module('template');
		  $this->template->admin($data);
		  $this->template->admin_side($data);
		
	}
	public function contact_add()
		{
			$groups = $this->input->post('groups');
			$groups = implode(',', $groups);
			$user_id = 1;
			$time = time();
			$data = array(
				'id' => $this->input->post('id'),
				'user_id' => $user_id,
				'name' => $this->input->post('name'),
				'email' => $this->input->post('email'),
				'phone' => $this->input->post('phone'),
				'gender' => $this->input->post('gender'),
				'groups' => $groups,
				'location' => $this->input->post('location'),
				'created' => $time,


				);
			$insert = $this->contacts_m->contact_add($data);
			echo json_encode(array("status" => TRUE));
		}
		public function ajax_edit($id)
		{
			$data = $this->contacts_m->get_by_id($id);



			echo json_encode($data);
		}

		public function contact_update()
	{
		$groups = $this->input->post('groups');
		$groups = implode(',', $groups);
		$data = array(
				'name' => $this->input->post('name'),
				'email' => $this->input->post('email'),
				'phone' => $this->input->post('phone'),
				'gender' => $this->input->post('gender'),
				'groups' => $groups,
				'location' => $this->input->post('location'),
			);
		$this->contacts_m->contact_update(array('id' => $this->input->post('id')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function contact_delete($id)
	{
		$this->contacts_m->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}


	public function ajax_bulk_send()
	{
			// $groups = $this->input->post('groups');
			// $groups = implode(',', $groups);
			// $user_id = 1;
			// $time = time();
			$data = array(
				'message' => $this->input->post('message'),
				


				);
			$url = 'api.rmlconnect.net:8080/bulksms/bulksms?username=Yield&password=xdARNvND';
			echo '<br><hr><h2>'.$this->postCURL($url, $params).'</h2><br><hr><br>';
			
	}

	public function postCURL($_url, $_param){

        $postData = '';
        //create name value pairs seperated by &
        foreach($_param as $k => $v) 
        { 
          $postData .= $k . '='.$v.'&'; 
        }
        rtrim($postData, '&');


        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, false); 
        curl_setopt($ch, CURLOPT_POST, count($postData));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);    

        $output=curl_exec($ch);

        curl_close($ch);

        return $output;
    }


    public function send_sms(){
    	//$phones = $this->input->post('phone');
		//foreach ($phones as $phone_n) {
		//	$phone = $phone_n;
		//}
    	//$phone = implode(',', $number);

    	$phone = $this->input->post('phone');
		$phone = implode(',', $phone);
    	$message = $this->input->post('message');
    	$data = array(
    		'username' 	=> 'Yield',//username to be here
    		'password' 	=> 'xdARNvND', //password field
    		'type'		=> 0,
    		'dlr'		=> 1,
    		'source'	=> $this->input->post('source'), //message source
    		'destination'=> $phone, //recipient
    		'message'	=> $this->input->post('message'), //message string
    		);
    	$string = http_build_query($data);

    	//echo $string; die();

    	$ch = curl_init("http://api.rmlconnect.net:8080/bulksms/bulksms?");
    	curl_setopt($ch, CURLOPT_POST, true);
    	curl_setopt($ch, CURLOPT_POSTFIELDS, $string);
    	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    	$response = curl_exec($ch);

    	echo $response;
    	curl_close($ch);
    	$log = array(
    		'id' 		=> 1,
    		'user_id'	=> 1,
    		'log'		=> $response,

    		);
    	$this->load->model('logs_m');
    	$insert = $this->logs_m->log_add($log);
		echo json_encode(array("status" => TRUE));

    }


}
