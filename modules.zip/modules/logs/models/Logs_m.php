<?php

defined('BASEPATH') OR exit('No direct script access allowed');



class Logs_m extends CI_Model

{



	var $table = 'logs';





	public function __construct()

	{

		parent::__construct();

		$this->load->database();

	}





public function get_all_contacts()

{

$this->db->from('logs');

$this->db->where('user_id', 1);

$query=$this->db->get();

return $query->result();

}



public function get_posts_by_sms_id($sms_id){

			$query = $this->db->get_where('logs', array('sms_id' => $sms_id));

			$result = $query->result();

			return $result;

			

		}







public function getSpecificMessageLog()

	{

	$user_id = $this->session->userdata('id');

	$sql = "SELECT id, created_at, log, message, source, sms_id, count(*) AS num FROM logs WHERE user_id = $user_id group by sms_id order by created_at asc";

	$query = $this->db->query($sql);

	return $query->result();

	}



	public function getDetails($sms_id)

	{

	$user_id = $this->session->userdata('id');

	$this->db->from('logs');

	$this->db->where('sms_id', $sms_id);

	$this->db->where('user_id', $user_id);

	$query=$this->db->get();

	return $query->result();

	}



public function getAllLogs()

	{

	$user_id = $this->session->userdata('id');

	$this->db->from('logs');

	$this->db->where('user_id', $user_id);

	$query=$this->db->get();

	return $query->result();

	}





public function countTotalSms()

	{

		$user_id = $this->session->userdata('id');

		$sql = "SELECT * FROM logs WHERE user_id = $user_id";

		$query = $this->db->query($sql);

		return $query->num_rows();

	}





	public function get_by_id($id)

	{

		$this->db->from($this->table);

		$this->db->where('id',$id);

		$query = $this->db->get();



		return $query->row();

	}



	public function log_add($data)

	{

		$this->db->insert($this->table, $data);

		return $this->db->insert_id();

	}



	public function contact_update($where, $data)

	{

		$this->db->update($this->table, $data, $where);

		return $this->db->affected_rows();

	}



	public function delete_by_id($id)

	{

		$this->db->where('id', $id);

		$this->db->delete($this->table);

	}



	function get_where($id){

    $table = $this->get_table();

    $this->db->where('id', $id);

    $query=$this->db->get($table);

    return $query;

}



function _custom_query($mysql_query) {

    $query = $this->db->query($mysql_query);

    return $query;

}





}



