
<div class="row">
	<div class="col-md-12">
		<h1><?=$pageTitle?></h1>
		<?=validation_errors("<div class='alert alert-danger alert-bordered'>",
	"<button type='button' class='close' data-dismiss='alert'><span>×</span><span class='sr-only'>Close</span></button>
</div>"); ?>
<?php
if (isset($flash)){
	echo $flash;
}

 ?>
<?php
 $form_location= base_url()."nematologist/submit/".$update_id;

 $edit_url= base_url()."nematologist/edit/".$update_id;

  ?>

	</div>
</div>
<div class="row mb-5">

<?php echo Modules::run('template/breadcrumb', $breadcrumbs_data); ?>
<?php if($query->num_rows()>0){ ?>
	<div class="col-md-12">
			<div class="card">
				<div class="card-header"><?=$pageTitle?></div>
					<div class="card-body">
						<dl class="row">
							<?php foreach ($query->result() as $row) {
									$diagnosis_report = $row->diagnosis_report;
									}
								?>
							<dt class="col-sm-3">Diagnosis Notes</dt>
							<dd class="col-sm-9"><?=$diagnosis_report?></dd>

							<dt class="col-sm-3">Comment</dt>
							<dd class="col-sm-9">
								<p><?=$additional_comment?></p>
							</dd>

						</dl>
						<a class="btn btn-primary btn-sm" href="<?=$edit_url?>">Edit</a>

</div>
</div>

</div>

<?php } else { ?>
	<div class="col-md-12">
		<div class="card">
			<div class="card-body">
				<div class="row">
					<div class="col-lg-12">
						<form method="post" action="<?=$form_location;?>" enctype="multipart/form-data">
							<div class="form-group">
								<label for="exampleFormControlTextarea1" class="">Diagnosis Report</label>
								<textarea class="form-control" name="diagnosis_report" id="exampleFormControlTextarea1" rows="3"></textarea>
							</div>
							<div class="form-group">
								<label for="exampleFormControlTextarea1" class="">Recomendations (optional)</label>
								<textarea class="form-control" name="additional_comment" id="exampleFormControlTextarea2" rows="3"></textarea>
							</div>

							<div class="form-group row">
								<div class="col-sm-10">
									<button type="submit" name="submit" value="Submit" class="btn btn-primary">Submit</button>
								</div>
							</div>
						</form>
						<br>
						<br>


					</div>
				</div>
			</div>
		</div>
	</div>
<?php } ?>

</div>

<script>
	 // Replace the <textarea id="editor1"> with a CKEditor
	 // instance, using default configuration.
	 CKEDITOR.replace( 'exampleFormControlTextarea1' );
	 CKEDITOR.replace( 'exampleFormControlTextarea2' );
</script>
