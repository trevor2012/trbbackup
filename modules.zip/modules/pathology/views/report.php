<?php if($query->num_rows()>0){ ?>
<div class="card-header">PATHOLOGY RESULTS</div>
  <div class="card-body">
    <?php
    $this->load->module('user_accounts');
    foreach ($query->result() as $row) {
        $diagnosis_report = $row->diagnosis_report;
        $additional_comment = $row->additional_comment;
        $username = $this->user_accounts->_get_username($row->user_id);
        }
      ?>
<dl class="row">

  <dt class="col-sm-3">Diagnosis Notes</dt>
  <dd class="col-sm-9"><?=$diagnosis_report?></dd>

  <dt class="col-sm-3">Comment</dt>
  <dd class="col-sm-9"><?=$additional_comment?>
  </dd>
  <p class="pull-right">By: <?=$username?></p>
  </dd>

</dl>
</div>
<?php } ?>
