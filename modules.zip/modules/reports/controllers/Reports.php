<?php
class Reports extends MX_Controller 
{

function __construct() {
parent::__construct();
$this->load->module('site_security');
$this->load->module('user_accounts');
$this->load->module('farmers');
}
    
    
public function index()
{
    $this->load->module('user_accounts');
    $data['query'] = $this->user_accounts->get('lastname');
    $data['view_module'] = "reports";
    $data['view_file'] = "index";
    $this->load->module('template');
    $this->template->header($data);
    $this->template->sidebar($data);
    $this->template->footer($data);
}
    
    
    
    
    
    
    
    
    
    
    
}