<div class="row">
    <div class="col-md-6 col-lg-6 col-xl-3 mb-5">
        <div class="card card-tile card-xs bg-primary bg-gradient text-center">
            <div class="card-body p-4">
                <!-- Accepts .invisible: Makes the items. Use this only when you want to have an animation called on it later -->
                <div class="tile-left">
                    <i class="batch-icon batch-icon-user-alt batch-icon-xxl"></i>
                </div>
                <div class="tile-right">
                    <div class="tile-number">3</div>
                    <div class="tile-description">Users</div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-6 col-xl-3 mb-5">
        <div class="card card-tile card-xs bg-secondary bg-gradient text-center">
            <div class="card-body p-4">
                <div class="tile-left">
                    <i class="batch-icon batch-icon-tag-alt-2 batch-icon-xxl"></i>
                </div>
                <div class="tile-right">
                    <div class="tile-number">$0000</div>
                    <div class="tile-description">Sales</div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-6 col-xl-3 mb-5">
        <div class="card card-tile card-xs bg-primary bg-gradient text-center">
            <div class="card-body p-4">
                <div class="tile-left">
                    <i class="batch-icon batch-icon-list batch-icon-xxl"></i>
                </div>
                <div class="tile-right">
                    <div class="tile-number">3</div>
                    <div class="tile-description">Messages Sent</div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-6 col-xl-3 mb-5">
        <div class="card card-tile card-xs bg-secondary bg-gradient text-center">
            <div class="card-body p-4">
                <div class="tile-left">
                    <i class="batch-icon batch-icon-star batch-icon-xxl"></i>
                </div>
                <div class="tile-right">
                    <div class="tile-number">17</div>
                    <div class="tile-description">Farmers</div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-6 col-lg-6 col-xl-8 mb-5">
        <div class="card card-md">
            <div class="card-header">
                Sales Overview
                <div class="header-btn-block">
                    <span class="data-range dropdown">
                        <a href="#" class="btn btn-primary dropdown-toggle" id="navbar-dropdown-sales-overview-header-button" data-toggle="dropdown" data-flip="false" aria-haspopup="true" aria-expanded="false">
                            <i class="batch-icon batch-icon-calendar"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbar-dropdown-sales-overview-header-button">
                            <a class="dropdown-item" href="today">Today</a>
                            <a class="dropdown-item" href="week">This Week</a>
                            <a class="dropdown-item" href="month">This Month</a>
                            <a class="dropdown-item active" href="year">This Year</a>
                        </div>
                    </span>
                </div>
            </div>
            <div class="card-body">
                <div class="card-chart" data-chart-color-1="#07a7e3" data-chart-color-2="#32dac3" data-chart-legend-1="Sales ($)" data-chart-legend-2="Samples">
                    <canvas id="sales-overview"></canvas>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-6 col-xl-4 mb-5">
        <div class="card card-md">
            <div class="card-header">
                Traffic Sources
                <div class="header-btn-block">
                    <span class="data-range dropdown">
                        <a href="#" class="btn btn-primary dropdown-toggle" id="navbar-dropdown-traffic-sources-header-button" data-toggle="dropdown" data-flip="false" aria-haspopup="true" aria-expanded="false">
                            <i class="batch-icon batch-icon-calendar"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbar-dropdown-traffic-sources-header-button">
                            <a class="dropdown-item" href="today">Today</a>
                            <a class="dropdown-item" href="week">This Week</a>
                            <a class="dropdown-item" href="month">This Month</a>
                            <a class="dropdown-item active" href="year">This Year</a>
                        </div>
                    </span>
                </div>
            </div>
            <div class="card-body text-center">
                <p class="text-left">Your top 5 traffic sources</p>
                <div class="card-chart" data-chart-color-1="#07a7e3" data-chart-color-2="#32dac3" data-chart-color-3="#4f5b60" data-chart-color-4="#FCCF31" data-chart-color-5="#f43a59">
                    <canvas id="traffic-source"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row mb-5">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                User Management
            </div>
            <div class="card-table table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="thead-light">
                        <tr>
                            <th>Member</th>
                            <th>Email</th>
                            <th class="text-center">Role</th>
                            <th>Created</th>
                            <th class="text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                          
                           <?php 
                            $this->load->module('timedate');
                            foreach($query->result() as $row){
                                $edit_page_url = base_url()."user_accounts/create/".$row->id;
                                $view_page_url = base_url()."user_accounts/individual/".$row->id;
                                $delete_page_url = base_url()."user_accounts/deleteconf/".$row->id;
                                $date_made = $this->timedate->get_nice_date($row->date_made, 'mini'); 
                            ?>
                            <td>
                                <div class="media">
                                    <div class="media-body">
                                        <div class="heading mt-1">
                                           <?=$row->firstname?> <?=$row->lastname?>
                                        </div>
                                        <div class="subtext"><?=$row->username?></div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <a href="#"><?php echo $row->email; ?></a>
                            </td>
                            <td class="text-center">
                                <?php echo $row->role; ?>
                            </td>
                            <td><?php echo $date_made; ?></td>
                            <td class="text-right">
                                <a class="btn btn-primary">
                                    <i class="batch-icon batch-icon-eye"></i>
                                </a>
                                <a class="btn btn-success">
                                    <i class="batch-icon batch-icon-quill"></i>
                                </a>
                            </td>
                        </tr>
                        <?php } ?>
        
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>