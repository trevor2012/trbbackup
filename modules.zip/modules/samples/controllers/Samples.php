<?php
class Samples extends MX_Controller
{

function __construct() {
parent::__construct();
 $this->load->module('site_security');
$this->load->module('farmers');
}
function delete($update_id){

    $this->load->module('site_security');
   $this->site_security->_make_sure_logged_in();

    $submit = $this->input->post('submit', TRUE);
    if ($submit=="Cancel") {
        redirect('samples');
    } elseif($submit=="Yes - Delete Page"){
        $this->_process_delete($update_id);

        $flash_msg = "Farmer details were successfully deleted.";
        $value = '<div class="alert alert-success" role="alert">'.$flash_msg. '</div>';
        $this->session->set_flashdata('item', $value);

        redirect('samples');
    }

}

function _draw_details($update_id)
{
  $this->site_security->_make_sure_logged_in();
  $update_id = $this->uri->segment(3);
  $record_id =$this->session->userdata('code');
  $data = $this->farmers->fetch_data_from_db($update_id);
  $breadcrumbs_data['template'] = 'breadcrumb';
  $breadcrumbs_data['current_page_title'] = $data['first_name'];
  $breadcrumbs_data['breadcrumbs_array'] = $this->_generate_breadcrumb_array($update_id);
  $data['update_id'] = $this->uri->segment(3);
  $data['breadcrumbs_data'] = $breadcrumbs_data;
  $data['query'] = $this->farmers_m->getChemicals($record_id);
  $this->load->view('details', $data);
}

function deleteconf($update_id){
    if (!is_numeric($update_id)){
        redirect('site_security/not_allowed');
    }

    $this->load->module('site_security');
    $this->site_security->_make_sure_logged_in();

    $data['pageTitle'] = "Delete Farmer";
    $data['update_id'] = $update_id;
    $data['tableTitle'] = "Delete Farmer";
    $data['flash'] = $this->session->flashdata('item');
    $data['view_module'] = "samples";
    $data['view_file'] = "deleteconf";
    $this->load->module('template');
    $this->template->header($data);
    $this->template->sidebar($data);
    $this->template->footer($data);
}

function _process_delete($update_id){
    //delete record
    $this->farmers->_delete($update_id);
}


function index()
{
    $this->site_security->_make_sure_logged_in();
    $this->load->module('farmers');
    $data['query'] = $this->farmers->get('id');
    $data['pageTitle'] = "Samples";
    $data['view_module'] = "samples";
    $data['tableTitle'] = "Samples";
    $data['view_file'] = 'index';
    $this->load->module('template');
    $this->template->header($data);
    $this->template->sidebar($data);
    $this->template->footer($data);
}

function details()
{
    $this->site_security->_make_sure_logged_in();
    $update_id = $this->uri->segment(3);
    $record_id =$this->session->userdata('code');
    $data = $this->farmers->fetch_data_from_db($update_id);



    $breadcrumbs_data['template'] = 'breadcrumb';
    $breadcrumbs_data['current_page_title'] = $data['first_name'];
    $breadcrumbs_data['breadcrumbs_array'] = $this->_generate_breadcrumb_array($update_id);




    $data['update_id'] = $this->uri->segment(3);
    $data['breadcrumbs_data'] = $breadcrumbs_data;
    $data['query'] = $this->farmers_m->getChemicals($record_id);
    $data['pageTitle'] = "Samples";
    $data['view_module'] = "samples";
    $data['tableTitle'] = "Samples";
    $data['view_file'] = 'sample';
    $this->load->module('template');
    $this->template->header($data);
    $this->template->sidebar($data);
    $this->template->footer($data);
}


function _generate_breadcrumb_array($update_id)
{
    $homepage_url = base_url();
    $second_level_url = base_url('samples');
    $breadcrumbs_array[$homepage_url] = "Home";
    $breadcrumbs_array[$second_level_url] = "Samples";

    return $breadcrumbs_array;
}

function report()
{
    $this->site_security->_make_sure_logged_in();
    $data['update_id'] = $this->uri->segment(3);
    $data['query'] = $this->get('id');
    $data['pageTitle'] = "Samples";
    $data['view_module'] = "samples";
    $data['tableTitle'] = "Samples";
    $data['view_file'] = 'report';
    $this->load->module('template');
    $this->template->header($data);
    $this->template->sidebar($data);
    $this->template->footer($data);
}

function pathology()
        {
            $update_id = $this->uri->segment(3);

            $this->load->module('site_security');
            //$this->site_security->_make_sure_is_admin();

            $update_id = $this->uri->segment(3);
            $submit = $this->input->post('submit', TRUE);

            if(!is_numeric($update_id)){
                redirect('samples');
            } elseif ($submit=="Cancel") {
                redirect('samples/details/'.$update_id);
            }


            if($submit=="Submit"){



                //Process the form

                $this->form_validation->set_rules('pathology_report', 'diagnosis report', 'required');




                if($this->form_validation->run() == TRUE) {


                    $data['pathology_report'] = $this->input->post('pathology_report');
                    $data['pathology_reco'] = $this->input->post('pathology_reco');
                    $data['pathology_status'] = 20;

                    //update user password details
                    $this->_update($update_id, $data);
                    $this->session->set_flashdata('report_added', 'The record has been successfully added');

                    redirect('samples/details/' .$update_id);
                   }
                }

            $data = $this->fetch_data_from_db($update_id);
            $data['update_id'] = $update_id;
            $flash = $this->session->flashdata('item');
            $data['pageTitle'] = "Pathology Diagnosis";
            $data['view_module'] = "samples";
            $data['view_file'] = "report";
            $this->load->module('template');
            $this->template->header($data);
            $this->template->sidebar($data);
            $this->template->footer($data);
}


function entomology()
        {
            $this->load->module('site_security');
            $update_id = $this->uri->segment(3);
            $submit = $this->input->post('submit', TRUE);
            if(!is_numeric($update_id)){
                redirect('samples');
            } elseif ($submit=="Cancel") {
                redirect('samples/details/'.$update_id);
            }
            if($submit=="Submit"){

                //Process the form

                $this->form_validation->set_rules('entomology_report', 'diagnosis report', 'required');


                if($this->form_validation->run() == TRUE) {
                    //get the variables from post


                   $data['entomology_report'] = $this->input->post('entomology_report');
                   $data['entomology_reco'] = $this->input->post('entomology_reco');

                    $this->_update($update_id, $data);
                    $this->session->set_flashdata('report_added', 'The record has been successfully added');

                    redirect('samples/details/' .$update_id);
                   }
                }

            $data = $this->fetch_data_from_db($update_id);
            $data['update_id'] = $update_id;
            $flash = $this->session->flashdata('item');
            $data['pageTitle'] = "Entomology Diagnosis";
            $data['view_module'] = "samples";
            $data['view_file'] = "entomology";
            $this->load->module('template');
            $this->template->header($data);
            $this->template->sidebar($data);
            $this->template->footer($data);
}

function nematology()
        {
            $this->load->module('site_security');
            $update_id = $this->uri->segment(3);
            $submit = $this->input->post('submit', TRUE);
            if(!is_numeric($update_id)){
                redirect('samples');
            } elseif ($submit=="Cancel") {
                redirect('samples/details/'.$update_id);
            }
            if($submit=="Submit"){

                //Process the form

                $this->form_validation->set_rules('nematology_report', 'diagnosis report', 'required');


                if($this->form_validation->run() == TRUE) {
                    //get the variables from post


                   $data['nematology_report'] = $this->input->post('nematology_report');
                   $data['nematology_reco'] = $this->input->post('nematology_reco');

                    $this->_update($update_id, $data);
                    $this->session->set_flashdata('report_added', 'The record has been successfully added');

                    redirect('samples/details/' .$update_id);
                   }
                }

            $data = $this->fetch_data_from_db($update_id);
            $data['update_id'] = $update_id;
            $flash = $this->session->flashdata('item');
            $data['pageTitle'] = "Nematology Diagnosis";
            $data['view_module'] = "samples";
            $data['view_file'] = "nematology";
            $this->load->module('template');
            $this->template->header($data);
            $this->template->sidebar($data);
            $this->template->footer($data);
}
function agronomy()
        {
            $this->load->module('site_security');
            $update_id = $this->uri->segment(3);
            $submit = $this->input->post('submit', TRUE);
            if(!is_numeric($update_id)){
                redirect('samples');
            } elseif ($submit=="Cancel") {
                redirect('samples/details/'.$update_id);
            }
            if($submit=="Submit"){

                //Process the form

                $this->form_validation->set_rules('agronomy_report', 'diagnosis report', 'required');


                if($this->form_validation->run() == TRUE) {
                    //get the variables from post


                   $data['agronomy_report'] = $this->input->post('agronomy_report');
                   $data['agronomy_reco'] = $this->input->post('agronomy_reco');

                    $this->_update($update_id, $data);
                    $this->session->set_flashdata('report_added', 'The record has been successfully added');

                    redirect('samples/details/' .$update_id);
                   }
                }

            $data = $this->fetch_data_from_db($update_id);
            $data['update_id'] = $update_id;
            $flash = $this->session->flashdata('item');
            $data['pageTitle'] = "Agronomy Report";
            $data['view_module'] = "samples";
            $data['view_file'] = "agronomy";
            $this->load->module('template');
            $this->template->header($data);
            $this->template->sidebar($data);
            $this->template->footer($data);
}
function analytical_chemistry()
        {
            $this->load->module('site_security');
            $update_id = $this->uri->segment(3);
            $submit = $this->input->post('submit', TRUE);
            if(!is_numeric($update_id)){
                redirect('samples');
            } elseif ($submit=="Cancel") {
                redirect('samples/details/'.$update_id);
            }
            if($submit=="Submit"){

                //Process the form

                $this->form_validation->set_rules('analytical_chem_report', 'diagnosis report', 'required');


                if($this->form_validation->run() == TRUE) {
                    //get the variables from post


                   $data['analytical_chem_report'] = $this->input->post('analytical_chem_report');
                   $data['analytical_chem_reco'] = $this->input->post('analytical_chem_reco');

                    $this->_update($update_id, $data);
                    $this->session->set_flashdata('report_added', 'The record has been successfully added');

                    redirect('samples/details/' .$update_id);
                   }
                }

            $data = $this->fetch_data_from_db($update_id);
            $data['update_id'] = $update_id;
            $flash = $this->session->flashdata('item');
            $data['pageTitle'] = "Analytical Chemistry Report";
            $data['view_module'] = "samples";
            $data['view_file'] = "analytical_chemistry";
            $this->load->module('template');
            $this->template->header($data);
            $this->template->sidebar($data);
            $this->template->footer($data);
}
function soil_chemistry()
        {
            $this->load->module('site_security');
            $update_id = $this->uri->segment(3);
            $submit = $this->input->post('submit', TRUE);
            if(!is_numeric($update_id)){
                redirect('samples');
            } elseif ($submit=="Cancel") {
                redirect('samples/details/'.$update_id);
            }
            if($submit=="Submit"){

                //Process the form

                $this->form_validation->set_rules('soil_chem_report', 'diagnosis report', 'required');


                if($this->form_validation->run() == TRUE) {
                    //get the variables from post


                   $data['soil_chem_report'] = $this->input->post('soil_chem_report');
                   $data['soil_chem_reco'] = $this->input->post('soil_chem_reco');

                    $this->_update($update_id, $data);
                    $this->session->set_flashdata('report_added', 'The record has been successfully added');

                    redirect('samples/details/' .$update_id);
                   }
                }

            $data = $this->fetch_data_from_db($update_id);
            $data['update_id'] = $update_id;
            $flash = $this->session->flashdata('item');
            $data['pageTitle'] = "Soil Chemistry Report";
            $data['view_module'] = "samples";
            $data['view_file'] = "soil_chemistry";
            $this->load->module('template');
            $this->template->header($data);
            $this->template->sidebar($data);
            $this->template->footer($data);
}


 function fetch_data_from_post(){
            $data['pathology_report'] = $this->input->post('pathology_report', TRUE);
            $data['pathology_reco'] = $this->input->post('pathology_reco', TRUE);
            return $data;
        }

function fetch_data_from_db($update_id){
            $query = $this->get_where($update_id);
            foreach ($query->result() as $row) {
                $data['sample_id'] = $row->sample_id;
                $data['pathology_report'] = $row->pathology_report;
                $data['pathology_reco'] = $row->pathology_reco;
                $data['entomology_report'] = $row->entomology_report;
                $data['entomology_reco'] = $row->entomology_reco;
                $data['nematology_report'] = $row->nematology_report;
                $data['nematology_reco'] = $row->nematology_reco;
                $data['agronomy_report'] = $row->agronomy_report;
                $data['agronomy_reco'] = $row->agronomy_reco;
                $data['analytical_chem_report'] = $row->analytical_chem_report;
                $data['analytical_chem_reco'] = $row->analytical_chem_reco;
                $data['soil_chem_report'] = $row->soil_chem_report;
                $data['soil_chem_reco'] = $row->soil_chem_reco;

            }

            if (!isset($data)) {
                $data = "";
            }

            return $data;
        }

function get($order_by)
{
    $this->load->model('samples_m');
    $query = $this->samples_m->get($order_by);
    return $query;
}

function get_with_limit($limit, $offset, $order_by)
{
    if ((!is_numeric($limit)) || (!is_numeric($offset))) {
        die('Non-numeric variable!');
    }

    $this->load->model('samples_m');
    $query = $this->samples_m->get_with_limit($limit, $offset, $order_by);
    return $query;
}

function get_where($id)
{
    if (!is_numeric($id)) {
        die('Non-numeric variable!');
    }

    $this->load->model('samples_m');
    $query = $this->samples_m->get_where($id);
    return $query;
}

function get_where_custom($col, $value)
{
    $this->load->model('samples_m');
    $query = $this->samples_m->get_where_custom($col, $value);
    return $query;
}

function _insert($data)
{
    $this->load->model('samples_m');
    $this->samples_m->_insert($data);
}

function _update($id, $data)
{
    if (!is_numeric($id)) {
        die('Non-numeric variable!');
    }

    $this->load->model('samples_m');
    $this->samples_m->_update($id, $data);
}

function _delete($id)
{
    if (!is_numeric($id)) {
        die('Non-numeric variable!');
    }

    $this->load->model('samples_m');
    $this->samples_m->_delete($id);
}

function count_where($column, $value)
{
    $this->load->model('samples_m');
    $count = $this->samples_m->count_where($column, $value);
    return $count;
}

function get_max()
{
    $this->load->model('samples_m');
    $max_id = $this->samples_m->get_max();
    return $max_id;
}

function _custom_query($mysql_query)
{
    $this->load->model('samples_m');
    $query = $this->samples_m->_custom_query($mysql_query);
    return $query;
}



}
