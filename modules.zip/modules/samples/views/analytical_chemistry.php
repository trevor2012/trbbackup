
<div class="row">
	<div class="col-md-12">
		<h1><?=$pageTitle?></h1>
		<?=validation_errors("<div class='alert alert-danger alert-bordered'>",
	"<button type='button' class='close' data-dismiss='alert'><span>×</span><span class='sr-only'>Close</span></button>
</div>"); ?>
<?php 
if (isset($flash)){
	echo $flash;
}

 ?>
<?php 
 $form_location= base_url()."samples/analytical_chemistry/".$update_id;

  ?>

	</div>
</div>
<div class="row mb-5">
	<div class="col-md-12">
		<div class="card">
			<div class="card-body">
				<div class="row">
					<div class="col-lg-12">
						<form method="post" action="<?=$form_location;?>">
							<div class="form-group">
								<label for="exampleFormControlTextarea1" class="">Diagnosis Report</label>
								<textarea class="form-control" name="analytical_chem_report" id="exampleFormControlTextarea1" rows="3"><?=$analytical_chem_report?></textarea>
							</div>
							<div class="form-group">
								<label for="exampleFormControlTextarea1" class="">Recomendations (optional)</label>
								<textarea class="form-control" name="analytical_chem_reco" id="exampleFormControlTextarea1" rows="3"><?=$analytical_chem_reco?></textarea>
							</div>
							 
							<div class="form-group row">
								<div class="col-sm-10">
									<button type="submit" name="submit" value="Submit" class="btn btn-primary">Submit</button>
								</div>
							</div>
						</form>
						<br>
						<br>

			
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
