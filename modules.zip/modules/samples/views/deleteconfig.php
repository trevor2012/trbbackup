<?php 

if (isset($flash)) {
	echo $flash;
}

 ?>
 <?php
 $attributes = array('class' => 'form-horizontal');
 echo form_open('samples/delete/'.$update_id);

  ?>



 <p style="margin-left:20px;">Are you sure you want to delete farmer details?</p>

 

  <fieldset>
  	<div class="control-group" style="height:200px;">
  		
  		<button style="margin-left:20px;" type="submit" name="submit" value="Yes - Delete Page" class="btn btn-danger">Delete</button>
  		
  		<button style="margin-left:20px;" type="submit" name="submit" value="Cancel" class="btn">Cancel</button>
  	</div>
  </fieldset>

  <form>