



<?php

$pathology_url = base_url()."pathology/update/".$update_id;
$entomology_url = base_url()."entomologist/update/".$update_id;
$nematology_url = base_url()."nematologist/update/".$update_id;
$agronomy_url = base_url()."agronomist/update/".$update_id;
$analytical_chemistry_url = base_url()."analytical_chemistry/update/".$update_id;
$soil_chemistry_url = base_url()."soil_chemistry/update/".$update_id;


 ?>

	<?php


if($this->session->flashdata('report_added')): ?>
        <?php echo '<p class="alert alert-success">'.$this->session->flashdata('report_added').'</p>'; ?>
      <?php endif;


$status = "danger";
	 ?>







			<p class="lead text-center">PLANT CLINIC</p>
			<hr />
			<div class="row">
				<div class="col-sm-4">
					<h3>REPORT FOR:</h3>
					<address>
						<strong><?=$first_name?> <?=$last_name?><br></strong>
                    </address>
					<address>
						<?=$postal_address?><br>
						<?=$district?><br>
						<?=$email?><br>
						<?=$tell?>
					</address>


				</div>
				<div class="col-sm-4">

				</div>
				<div class="col-sm-4">


					<h3>Crop Details:</h3>
					<strong>TRB No:</strong><?=$this->session->userdata('code');?><br>
					<strong>CROP:</strong>
					<?=$crop?><br>
					<strong>VARIETY:</strong>
					<?=$variety?><br>
					<strong>SOWING/PLANTING DATE:</strong>
					<?=$sowing_date?>
				</div>
			</div>


		<hr>
<div class="row">
    <div class="col-md-6">
        <div class="card-table table-responsive">

            <p class="lead" style="margin-left:; background-color:green; color:white;">DESCRIPTION OF PROBLEM</p>
			<table class="table">

		    <tr>
		      <th scope="row">Plant Parts</th>
                <td><?=$plant_parts?></td>
		    </tr>
		    <tr>
		      <th scope="row">Symptoms</th>
		      <td><?=$symptoms?></td>

		    </tr>
		    <tr>
		      <th scope="row">Distribution</th>
		      <td><?=$distribution?></td>

		    </tr>
		</table>
	</div>
    </div>
    <div class="col-md-6">
       	<div class="card-table table-responsive">

				<p class="lead" style="margin-left:; background-color:green; color:white;">ADDITIONAL INFORMATION</p>
			<table class="table">

		    <tr>
		      <th scope="row">History of site</th>
		      <td><?=$history_of_site?></td>

		    </tr>
		    <tr>
		      <th scope="row">Other crops</th>
		      <td><?=$other_crops?></td>
		    </tr>

		</table>
	</div>
    </div>
</div>





	<div class="card-table table-responsive">

				<p class="lead" style="margin-left:; background-color:green; color:white;">CHEMICALS AND FERTILIZERS USED: SEEDBED/FIELD</p>
	<table class="table">
	  <thead>
	    <tr>
	      <th scope="col">Name</th>
	      <th scope="col">Method Used</th>
	      <th scope="col">Type of Application</th>
	      <th scope="col">Thereafter applied</th>

	    </tr>
	  </thead>
	  <tbody>
    <?php
    foreach($query->result() as $row){
    ?>
	    <tr>
	      <td><?=$row->item?></td>
	      <td><?=$row->method_used?></td>
	      <td><?=$row->time_of_application?></td>
	      <td><?=$row->thereafter_applied?></td>
	    </tr>
	  <?php } ?>
	  </tbody>
	</table>
</div>
<hr>

<p class="lead" style="margin-left:; background-color:green; color:white;">OTHER USEFUL INFORMATION:</p>
<p style="margin-left: ;"><?=$other_useful_info?></p>


<hr><br>
<p class="lead" style="margin-left: ; background-color:green; color:white;">DIAGNOSIS TEST RESULTS</p>

<!-- pathology test results -->
<?php echo Modules::run('pathology/_report'); ?>
<?php echo Modules::run('entomologist/_report'); ?>
<?php echo Modules::run('nematologist/_report'); ?>
<?php echo Modules::run('analytical_chemistry/_report'); ?>
<?php echo Modules::run('soil-chemistry/_report'); ?>
<?php

$diagnosis_url = base_url('diagnosis/update/'.$update_id);
 ?>
<p class="pull-right"> <a class="btn btn-success" href="<?=$diagnosis_url?>">Add Report</a> </p>
