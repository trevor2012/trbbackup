<div class="row">
						<div class="col-md-12">
							<h1><?php echo $tableTitle; ?></h1>
						</div>
					</div>
					<div class="row mb-5">
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="row">

										<div class="col-lg-12 pb-5">


											<div class="table-responsive">
												<table id="datatable-1" class="table table-datatable table-striped table-hover">
													<thead>
														<tr>
															<th>SAMPLE NO:</th>
						                                    <th>FIRST NAME</th>
											                <th>LASTNAME</th>
											                <th>PHONE</th>
											                <th>GROWER NUMBER</th>
											                <th>STATUS</th>
						                                    <th>ACTION</th>
											            </tr>
													</thead>
													<tbody>
														 <?php
														 $this->load->module('timedate');
														 foreach($query->result()  as $row) {
															$edit_page_url = base_url()."user_accounts/create/".$row->id;
														 	$view_page_url = base_url()."samples/details/".$row->id;
														 	$delete_page_url = base_url()."samples/deleteconf/".$row->id;
														 	//$date_made = $this->timedate->get_nice_date($row->date_created, 'mini');

                                                            $status = $row->status;

                                                             if($status==0){
                                                                 $status = "pending";
                                                             }elseif($status==1){
                                                                 $status = "completed";
                                                             }
														 ?>
														<tr>
															<td><?php echo $row->record_id; ?></td>
															<td><?php echo $row->first_name; ?></td>
															<td><?php echo $row->last_name; ?></td>
						                                    <td><?php echo $row->tell; ?></td>
															<td><?php echo $row->growers_number; ?></td>
															<td><span class="badge badge-success"><?=$status?></span></td>


															<td>

																<span class="email-extra-icons">
																	<a href="<?= $view_page_url;?>"><i class="batch-icon batch-icon-eye"></i></a>
																	<a href="<?= $delete_page_url;?>"><i style="color:red;" class="batch-icon batch-icon-bin-alt-2"></i></a>
																</span>
															</td>
														</tr>
													 <?php } ; ?>
													</tbody>
												</table>
											</div>
										</div>


									</div>
								</div>
							</div>
						</div>
					</div>
