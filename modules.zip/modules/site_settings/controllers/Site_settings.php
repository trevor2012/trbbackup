<?php
class Site_settings extends MX_Controller
{

function __construct() {
parent::__construct();
}
function _get_support_team_name(){
  $name = "Customer Support";
  return $name;
}

function _get_welcome_message($customer_id){
  $this->load->module('user_accounts');
  $customer_name = $this->user_accounts->_get_customer_name($customer_id);

  $msg = "Hello ".$customer_name.", <br>";
  $msg.= "Thank you for creating an account with us. If you have any questions";
  $msg.= "please do get in touch. <br><br>";
  $msg.= "Regards<br><br>";
  $msg.= "Trevor";

}


function _get_our_name(){
  $name = "ONEVISIONCONNECT";
  return $name;
}

function _get_our_address(){
  $our_address = 'Cnr R Manyika and Sam Nujoma<br>';
  $our_address.= '43 Merchant Hse Rm 306';
  return our_address;
}

function _get_our_telnum(){
  $telnum = "(+263) 777752473";
  return $telnum;
}

function _get_cookie_name()
{
   $cookie_name = 'trvhvam';
   return $cookie_name;
}

function _get_page_not_found_msg(){
    $msg= "<section class='main-container jumbotron light-gray-bg text-center margin-clear'>";
    $msg.= "<div class='row'><div class='main col-md-6 col-md-offset-3 pv-40'><h1><h1 class='page-title'><span class='text-default'>404</span></h1>";
    $msg.= "<h2>Ooops! Page Not Found</h2>";
    $msg.= "<p>The requested URL was not found on this server. Make sure that the Web site address displayed in the address bar of your browser is spelled and formatted correctly.</p></div></div>";
    return $msg;
}

}
