<?php
class Template extends MX_Controller
{

function __construct() {
parent::__construct();
}



function breadcrumb($data)
{
    $this->load->view('breadcrumb', $data);
}


function header($data)
{
    $this->load->view('header', $data);
}

function sidebar($data)
{
    $this->load->view('sidebar', $data);
}

function footer($data)
{
  $this->load->view('footer', $data);

}
function login_header($data)
{
  $this->load->view('login_header', $data);

}
function login_footer($data)
{
  $this->load->view('login_footer', $data);

}













}
