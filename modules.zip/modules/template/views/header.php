<!DOCTYPE html>
<html lang="en">
<head>
<?php

ini_set('display_errors', 'Off');
	 ?>
	<!-- Global site tag (gtag.js) - Google Analytics -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" href="<?=base_url()?>assets/img/favicon.png">

	<title>TRB | <?=$pageTitle?></title>

	<!-- Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,700&amp;subset=latin-ext" rel="stylesheet">

	<!-- CSS - REQUIRED - START -->
	<!-- Batch Icons -->
	<link rel="stylesheet" href="<?=base_url()?>assets/fonts/batch-icons/css/batch-icons.css">
	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="<?=base_url()?>assets/css/bootstrap/bootstrap.min.css">
	<!-- Material Design Bootstrap -->
	<link rel="stylesheet" href="<?=base_url()?>assets/css/bootstrap/mdb.min.css">
	<!-- Custom Scrollbar -->
	<link rel="stylesheet" href="<?=base_url()?>assets/plugins/custom-scrollbar/jquery.mCustomScrollbar.min.css">
	<!-- Hamburger Menu -->
	<link rel="stylesheet" href="<?=base_url()?>assets/css/hamburgers/hamburgers.css">

	<!-- CSS - REQUIRED - END -->

	<!-- CSS - OPTIONAL - START -->
	<!-- Font Awesome -->
	<link rel="stylesheet" href="<?=base_url()?>assets/fonts/font-awesome/css/font-awesome.min.css">
	<!-- Font Awesome -->
	<link rel="stylesheet" href="<?=base_url()?>assets/fonts/font-awesome/css/font-awesome.min.css">
	<!-- JVMaps -->
	<!-- Font Awesome -->
	<link rel="stylesheet" href="<?=base_url()?>assets/fonts/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?=base_url()?>assets/plugins/datatables/css/responsive.dataTables.min.css">
	<link rel="stylesheet" href="<?=base_url()?>assets/plugins/datatables/css/responsive.bootstrap4.min.css">
	<!-- CSS - OPTIONAL - END -->

	<!-- CSS - OPTIONAL - END -->

	<!-- QuillPro Styles -->
	<link rel="stylesheet" href="<?=base_url()?>assets/css/quillpro/quillpro.css">
	<script src="https://cdn.ckeditor.com/4.9.1/standard/ckeditor.js"></script>
</head>

<body>
	<div class="container-fluid">
		<div class="row">
			<!--
			<nav>: accepts .sidebar-hidden
			-->
			<!-- <nav id="sidebar" class="px-0 bg-dark bg-gradient sidebar sidebar-hidden">
				<ul class="nav nav-pills flex-column"> -->

			<nav id="sidebar" class="px-0 bg-dark bg-gradient sidebar">
				<ul class="nav nav-pills flex-column">
					<li class="logo-nav-item">
						<a class="navbar-brand" href="<?=base_url()?>">
							<img src="<?=base_url()?>assets/img/favicon.png" width="80" height="80" alt="TRB">
						</a>

					</li>
					<li>
						<h6 class="nav-header">General</h6>
					</li>

<!-- 	<div class="container-fluid">
		<div class="row">
			<nav id="sidebar" class="px-0 bg-dark bg-gradient sidebar">
				<ul class="nav nav-pills flex-column">
					<li class="logo-nav-item">
						<a class="navbar-brand" href="#">
							<img src="<?=base_url()?>assets/img/favicon.png" width="1" height="145" alt="TRB">
						</a>
					</li>
					<li>
						<h6 class="nav-header">TRB </h6>
					</li> -->
					<?php
					if($this->session->userdata['role']=='admin'){
					?>
					<li class="nav-item">
						<a class="nav-link" href="<?=base_url()?>farmers">
							<i class="batch-icon batch-icon-browser-alt"></i>
							Dashboard <span class="sr-only">(current)</span>
						</a>
					</li>
					<li class="nav-item">
						<a class="nav-link nav-parent" href="#">
							<i class="batch-icon batch-icon-layout-content-left"></i>
							Users
						</a>
						<ul class="nav nav-pills flex-column">
							<li class="nav-item">
								<a class="nav-link" href="<?=base_url()?>user-accounts/manage">Manage Users</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="<?=base_url()?>user-accounts/create">Add Users</a>
							</li>

						</ul>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="<?=base_url()?>farmers">
							<i class="batch-icon batch-icon-browser-alt"></i>
							Farmers
						</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="<?=base_url()?>samples">
							<i class="batch-icon batch-icon-browser-alt"></i>
							Samples
						</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="<?=base_url()?>reports">
							<i class="batch-icon batch-icon-browser-alt"></i>
							Reports
						</a>
					</li>

				<?php } ?>

					<?php
					if($this->session->userdata['role']=='accounts'){
					?>

					<li class="nav-item">
						<a class="nav-link" href="<?=base_url()?>accounts">
							<i class="batch-icon batch-icon-browser-alt"></i>
							Accounts
						</a>
					</li>

				<?php } ?>
				<?php
				if($this->session->userdata['role']=='pathologist'){
				?>
				<li class="nav-item">
					<a class="nav-link" href="<?=base_url()?>farmers">
						<i class="batch-icon batch-icon-browser-alt"></i>
						Farmers
					</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="<?=base_url()?>samples">
						<i class="batch-icon batch-icon-browser-alt"></i>
						Samples
					</a>
				</li>

				<li class="nav-item">
					<a class="nav-link" href="<?=base_url()?>accounts">
						<i class="batch-icon batch-icon-browser-alt"></i>
						Accounts
					</a>
				</li>

			<?php } ?>
			<?php
			if($this->session->userdata['role']=="entomologist"){
			?>
			<li class="nav-item">
				<a class="nav-link" href="<?=base_url()?>farmers">
					<i class="batch-icon batch-icon-browser-alt"></i>
					Farmers
				</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="<?=base_url()?>samples">
					<i class="batch-icon batch-icon-browser-alt"></i>
					Samples
				</a>
			</li>

			<li class="nav-item">
				<a class="nav-link" href="<?=base_url()?>accounts">
					<i class="batch-icon batch-icon-browser-alt"></i>
					Accounts
				</a>
			</li>

		<?php } ?>
		<?php
		if($this->session->userdata['role']=='nematologist'){
		?>
		<li class="nav-item">
			<a class="nav-link" href="<?=base_url()?>farmers">
				<i class="batch-icon batch-icon-browser-alt"></i>
				Farmers
			</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="<?=base_url()?>samples">
				<i class="batch-icon batch-icon-browser-alt"></i>
				Samples
			</a>
		</li>

		<li class="nav-item">
			<a class="nav-link" href="<?=base_url()?>accounts">
				<i class="batch-icon batch-icon-browser-alt"></i>
				Accounts
			</a>
		</li>

	<?php } ?>
	<?php
	if($this->session->userdata['role']=='technician'){
	?>
	<li class="nav-item">
		<a class="nav-link" href="<?=base_url()?>farmers">
			<i class="batch-icon batch-icon-browser-alt"></i>
			Farmers
		</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" href="<?=base_url()?>samples">
			<i class="batch-icon batch-icon-browser-alt"></i>
			Samples
		</a>
	</li>

	<li class="nav-item">
		<a class="nav-link" href="<?=base_url()?>accounts">
			<i class="batch-icon batch-icon-browser-alt"></i>
			Accounts
		</a>
	</li>

<?php } ?>
				</ul>
			</nav>
