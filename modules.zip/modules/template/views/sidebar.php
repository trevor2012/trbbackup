<div class="right-column">
		<nav class="navbar navbar-expand-lg navbar-light bg-white">
					<a class="navbar-brand d-block d-sm-block d-md-block d-lg-none" href="#">
						<img src="<?=base_url()?>assets/img/favicon.png" width="32.3" height="32.3" alt="TRB">
					</a>
					<button class="hamburger hamburger--slider" type="button" data-target=".sidebar" aria-controls="sidebar" aria-expanded="false" aria-label="Toggle Sidebar">
						<span class="hamburger-box">
							<span class="hamburger-inner"></span>
						</span>
					</button>
					<!-- Added Mobile-Only Menu -->
					<ul class="navbar-nav ml-auto mobile-only-control d-block d-sm-block d-md-block d-lg-none">
						<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle" id="navbar-notification-search-mobile" data-toggle="dropdown" data-flip="false" aria-haspopup="true" aria-expanded="false">
								<i class="batch-icon batch-icon-search"></i>
							</a>
							<ul class="dropdown-menu dropdown-menu-fullscreen" aria-labelledby="navbar-notification-search-mobile">
								<li>
									<form class="form-inline my-2 my-lg-0 no-waves-effect">
										<div class="input-group">
											<input type="text" class="form-control" placeholder="Search for..." aria-label="Search for..." aria-describedby="basic-addon2">
											<div class="input-group-append">
												<button class="btn btn-primary btn-gradient waves-effect waves-light" type="button">
													<i class="batch-icon batch-icon-search"></i>
												</button>
											</div>
										</div>
									</form>
								</li>
							</ul>
						</li>
					</ul>
					<div class="collapse navbar-collapse" id="navbar-header-content">
						<ul class="navbar-nav navbar-language-translation mr-auto">

						</ul>

						<ul class="navbar-nav ml-5 navbar-profile">
							<li class="nav-item dropdown">
								<a class="nav-link dropdown-toggle" id="navbar-dropdown-navbar-profile" data-toggle="dropdown" data-flip="false" aria-haspopup="true" aria-expanded="false">
									<div class="profile-name">
										<?php echo $this->session->userdata('firstname'); ?>
									</div>
									<div class="profile-picture bg-gradient bg-primary has-message float-right">

									</div>
								</a>
								<ul class="dropdown-menu dropdown-menu-right" aria-labelledby="navbar-dropdown-navbar-profile">
								<?php $id = $this->session->userdata('id');

								?>
									<li><a class="dropdown-item" href="<?php echo base_url('user_accounts/create/'.$id); ?>">Profile</a></li>
									<li><a class="dropdown-item" href="#">Settings</a></li>
									<li><a class="dropdown-item" href="<?=base_url()?>logout">Logout</a></li>
								</ul>
							</li>
						</ul>
					</div>
				</nav>

				<main class="main-content p-5" role="main">

					<?php if (isset($view_file)) {
					      	$this->load->view($view_module.'/'.$view_file);
					     }
					 ?>


				<div class="row mb-5">
					<div class="col-md-12">
						<footer>
							Powered by - <a href="#" target="_blank" style="font-weight:300;color:#ffffff;background:#1d1d1d;padding:0 3px;"><span style="color:#ffa733;font-weight:bold">dta</a>
						</footer>
					</div>
				</div>

				</main>




			</div>
		</div>
	</div>
