<?php
class Timedate extends MX_Controller
{

function __construct() {
parent::__construct();
}
function get_nice_date($timestamp, $format)
{
    switch($format){
        case 'full':
        //Full eg Thursday 18 May 2017 at 12:20:00 AM
        $the_date = date('l jS \of F Y \a\t h:i:s A', $timestamp);
        break;
        case 'cool':
        //Friday 18 May 2017
        $the_date = date('l jS \of F Y', $timestamp);
        break;
        case 'shorter':
        //18th of May 2017
        $the_date = date('jS \of F Y', $timestamp);
        break;

        case 'mini':
        // 18th May 2017
        $the_date = date('jS M Y', $timestamp);
        break;

        case 'full':
        //Full eg Thursday 18 May 2017 at 12:20:00 AM
        $the_date = date('l jS \of F Y \a\t h:i:s A', $timestamp);
        break;
    }

    return $the_date;
}





}
