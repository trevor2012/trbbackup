	<?php
	$first_bit = $this->uri->segment(1);
	$form_location = base_url().$first_bit.'/submit_login';
	 ?>
	<!-- main-container start -->
			<!-- ================ -->
			<div class="main-container dark-translucent-bg" style="background-image:url('<?=base_url()?>assets/images/backgrounds/bkground.jpg');">
				<div class="container">
					<div class="row">
						<!-- main start -->
						<!-- ================ -->
						<div class="main object-non-visible" data-animation-effect="fadeInUpSmall" data-effect-delay="100">
							<div class="form-block center-block p-30 light-gray-bg border-clear">
								<?php echo validation_errors("<div class='alert alert-danger alert-dismissible' role='alert'>
								<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button>", "</div>"); ?>
								<h2 class="title">Sign In</h2>
								<form class="form-horizontal" role="form" action="<?= $form_location ?>" method="post">

									<div class="form-group has-feedback">
										<label for="inputUserName" class="col-sm-3 control-label">Username or Email <span class="text-danger small">*</span></label>
										<div class="col-sm-8">
											<input type="text" class="form-control" name="username" value="<?=$username?>"  placeholder="Username or Email">
											<i class="fa fa-user form-control-feedback"></i>
										</div>
									</div>

									<div class="form-group has-feedback">
										<label for="inputPassword" class="col-sm-3 control-label">Password <span class="text-danger small">*</span></label>
										<div class="col-sm-8">
											<input type="password" class="form-control" name="pword"  placeholder="Password">
											<i class="fa fa-lock form-control-feedback"></i>
										</div>
									</div>
									<div class="form-group has-feedback">
									<div class="col-sm-offset-3 col-sm-8">
											<div class="checkbox">
												<?php if($first_bit=="users") { ?>
												<label>
													<input type="checkbox" name="remeber" value="remember-me"> Remember Me
												</label>
												<?php }  ?>
											</div>

										</div>
									</div>
									<div class="form-group">
										<div class="col-sm-offset-3 col-sm-8">
											<button type="submit" name="submit" value="Submit" class="btn btn-group btn-default btn-animated">Login</button>
										</div>
									</div>
								</form>
							</div>
						</div>
						<!-- main end -->
					</div>
				</div>
			</div>
			<!-- main-container end -->
