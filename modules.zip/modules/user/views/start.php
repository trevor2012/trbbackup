	<?php
	$form_location = base_url(). 'user/submit';
	 ?>
	<!-- main-container start -->
			<!-- ================ -->
			<div class="main-container dark-translucent-bg" style="background-image:url('<?=base_url()?>assets/images/backgrounds/bkground.jpg');">
				<div class="container">
					<div class="row">
						<!-- main start -->
						<!-- ================ -->

							<div class="form-block center-block p-30 light-gray-bg border-clear">
								<?php echo validation_errors("<div class='alert alert-danger alert-dismissible' role='alert'>
								<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button>", "</div>"); ?>
								<h2 class="title">Sign Up</h2>
								<form class="form-horizontal" role="form" action="<?= $form_location ?>" method="post">

									<div class="form-group has-feedback">
										<label for="inputUserName" class="col-sm-3 control-label">User Name <span class="text-danger small">*</span></label>
										<div class="col-sm-8">
											<input type="text" class="form-control" name="username" value="<?=$username?>"  placeholder="User Name">
											<i class="fa fa-user form-control-feedback"></i>
										</div>
									</div>
									<div class="form-group has-feedback">
										<label for="inputEmail" class="col-sm-3 control-label">Email <span class="text-danger small">*</span></label>
										<div class="col-sm-8">
											<input type="email" class="form-control" name="email" value="<?=$email?>"  placeholder="Email">
											<i class="fa fa-envelope form-control-feedback"></i>
										</div>
									</div>
									<div class="form-group has-feedback">
										<label for="inputPassword" class="col-sm-3 control-label">Password <span class="text-danger small">*</span></label>
										<div class="col-sm-8">
											<input type="password" class="form-control" name="pword" value="<?=$pword?>"  placeholder="Password">
											<i class="fa fa-lock form-control-feedback"></i>
										</div>
									</div>

									<div class="form-group has-feedback">
										<label for="inputPassword" class="col-sm-3 control-label">Repeat Password <span class="text-danger small">*</span></label>
										<div class="col-sm-8">
											<input type="password" class="form-control" name="repeat_pword" value="<?=$repeat_pword?>"  placeholder="Repeat Password">
											<i class="fa fa-lock form-control-feedback"></i>
										</div>
									</div>

									<div class="form-group">
										<div class="col-sm-offset-3 col-sm-8">
											<button type="submit" name="submit" value="Submit" class="btn btn-group btn-default btn-animated">Sign Up <i class="fa fa-check"></i></button>
										</div>
									</div>
								</form>
							</div>
						</div>
						<!-- main end -->
					</div>
				</div>

			<!-- main-container end -->
