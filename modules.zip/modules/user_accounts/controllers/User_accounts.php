<?php
class User_accounts extends MX_Controller
{

function __construct() {
parent::__construct();
 $this->load->module('site_security');





}
function _generate_token($update_id)
{

}

function _get_customer_id_from_token(){

}
function _get_customer_name($update_id){
  $data = $this->fetch_data_from_db($update_id);
  if ($data=="") {
    $customer_name = "Unkwown";
  } else{
    $firstname = trim($data['firstname']);
    $lastname = trim($data['lastname']);
    $company = trim($data['company']);
    $company_length = strlen($data['company']);
    if ($company_length>2) {
      $customer_name = $company;
    } else {
      $customer_name = ucfirst($firstname) . ' ' . ucfirst($lastname);
    }
  }
  return $customer_name;
}

function _get_username($update_id){
  $data = $this->fetch_data_from_db($update_id);
    $firstname = trim($data['firstname']);
    $lastname = trim($data['lastname']);

    $username = ucfirst($firstname) . ' ' . ucfirst($lastname);

    return $username;
}

function _get_title($update_id){
  $data = $this->fetch_data_from_db($update_id);
    $title = trim($data['title']);
    $credentials =  $title;

    return $credentials;
}




function update_password()
        {
            $this->load->module('site_security');
            //$this->site_security->_make_sure_is_admin();

            $update_id = $this->uri->segment(3);
            $submit = $this->input->post('submit', TRUE);

            if(!is_numeric($update_id)){
                redirect('user_accounts/manage');
            } elseif ($submit=="Cancel") {
                redirect('user_accounts/create/'.$update_id);
            }


            if($submit=="Submit"){



                //Process the form

                $this->form_validation->set_rules('pword', 'Password', 'required|min_length[7]|max_length[55]');
                $this->form_validation->set_rules('repeat_pword', 'Repeat Password', 'required|matches[pword]');


                if($this->form_validation->run() == TRUE) {
                    //get the variables from post

                   $data['pword'] = md5($this->input->post('pword'));

                    //update user password details
                    $this->_update($update_id, $data);
                    $flash_msg = "The Account password has been updated successfully";

                    $value = '<div class="alert alert-success alert-bordered">
                                <button type="button" class="close" data-dismiss="alert"><span>×</span><span class="sr-only">Close</span></button>
                                <span class="text-semibold">'.$flash_msg.'</span>
                            </div>';
                    $this->session->set_flashdata('item', $value);

                    redirect('user_accounts/create/' .$update_id);
                   }
                }


            $data['pageTitle'] = "Update Account Password";
            $data['update_id'] = $update_id;
            $flash = $this->session->flashdata('item');
            $data['view_module'] = "user_accounts";
            $data['view_file'] = "update_password";
            $this->load->module('template');
            $this->template->header($data);
            $this->template->sidebar($data);
            $this->template->footer($data);
}


//IMPORTANT CODE

function autogen(){
    $mysql_query = "show columns from user_accounts";
    $query = $this->_custom_query($mysql_query);

    foreach($query->result() as $row){
        $column_name = $row->Field;

        if ($column_name !="id") {

            echo  '$data[\''.$column_name.'\'] = $this->input->post(\''.$column_name.'\');<br>';
        }
    }
    echo "<hr>";

    foreach($query->result() as $row){
        $column_name = $row->Field;

        if ($column_name !="id") {

            echo  '$data[\''.$column_name.'\'] = $row->'.$column_name.';<br>';
        }
    }


echo "<hr>";
foreach($query->result() as $row){
        $column_name = $row->Field;

        if ($column_name !="id") {

           $var = '<div class="form-group">
        <label class="control-label col-lg-2">'.ucfirst($column_name).'</label>
        <div class="col-lg-10">
            <input type="text" name="'.$column_name.'" class="form-control" value="<?=$'.$column_name.'?>">
        </div>
    </div>';
    echo htmlentities($var);
    echo "<br>";
        }
    }







}

  function fetch_data_from_post(){
            $data['initial'] = $this->input->post('initial');
            $data['username'] = $this->input->post('username');
            $data['firstname'] = $this->input->post('firstname');
            $data['lastname'] = $this->input->post('lastname');
            $data['title'] = $this->input->post('title');
            $data['role'] = $this->input->post('role');
            $data['address1'] = $this->input->post('address1');
            $data['address2'] = $this->input->post('address2');
            $data['town'] = $this->input->post('town');
            $data['country'] = $this->input->post('country');
            $data['telnum'] = $this->input->post('telnum');
            $data['email'] = $this->input->post('email');
            return $data;
        }

        function fetch_data_from_db($update_id){
            $query = $this->get_where($update_id);
            foreach ($query->result() as $row) {
                $data['initial'] = $row->initial;
                $data['username'] = $row->username;
                $data['firstname'] = $row->firstname;
                $data['lastname'] = $row->lastname;
                $data['title'] = $row->title;
                $data['role'] = $row->role;
                $data['address1'] = $row->address1;
                $data['address2'] = $row->address2;
                $data['town'] = $row->town;
                $data['country'] = $row->country;
                $data['telnum'] = $row->telnum;
                $data['email'] = $row->email;

            }

            if (!isset($data)) {
                $data = "";
            }

            return $data;
        }

function create()
        {
            $this->site_security->_make_sure_logged_in();
            $this->load->module('site_security');
            //$this->site_security->_make_sure_is_admin();

            $update_id = $this->uri->segment(3);
            $submit = $this->input->post('submit', TRUE);

            if($submit=="Submit"){

                //Process the form
                $this->form_validation->set_rules('initial', 'initial', 'required');
                $this->form_validation->set_rules('firstname', 'firstname', 'required');
                $this->form_validation->set_rules('username', 'username', 'required');
                $this->form_validation->set_rules('lastname', 'lastname', 'required');
                $this->form_validation->set_rules('email', 'email', 'required');
                $this->form_validation->set_rules('telnum', 'telnum', 'required');


                if($this->form_validation->run() == TRUE) {
                    //get the variables from post
                   $data = $this->fetch_data_from_post();

                   if (is_numeric($update_id)){
                    //update user details


                    $this->_update($update_id, $data);
                    $flash_msg = "The Account has been updated successfully";

                    $value = '<div class="alert alert-success alert-bordered">
                                <button type="button" class="close" data-dismiss="alert"><span>×</span><span class="sr-only">Close</span></button>
                                <span class="text-semibold">'.$flash_msg.'</span>
                            </div>';
                    $this->session->set_flashdata('item', $value);

                    redirect('user_accounts/create/' .$update_id);
                   } else {
                    //insert new client

                    $data['date_made'] = time();
                    $this->_insert($data);

                    $update_id = $this->get_max(); //the id of the new client
                    $flash_msg = "The Account has been successfully added";

                    $value = '<div class="alert alert-success alert-bordered">
                                <button type="button" class="close" data-dismiss="alert"><span>×</span><span class="sr-only">Close</span></button>
                                <span class="text-semibold">'.$flash_msg.'</span>
                            </div>';
                    $this->session->set_flashdata('item', $value);

                    redirect('user_accounts/create/' .$update_id);
                   }
                }
            }
            if((is_numeric($update_id)) && ($submit !="Submit")){
                $data = $this->fetch_data_from_db($update_id);
            } else {
                //get the variables
                $data = $this->fetch_data_from_post();
            }

            if (!is_numeric($update_id)){
                $data['pageTitle'] ="Add New Account";

            } else {
                $data['pageTitle'] ="Update Account Details";
            }


            $data['update_id'] = $update_id;
            $flash = $this->session->flashdata('item');
            $data['view_module'] = "user_accounts";
            $data['view_file'] = "create";
            $this->load->module('template');
            $this->template->header($data);
            $this->template->sidebar($data);
            $this->template->footer($data);
}



function manage(){
    $this->site_security->_make_sure_logged_in();
    $this->load->module('site_security');
    //$this->site_security->_make_sure_is_admin();

    $data['query'] = $this->get('lastname');
    $data['pageTitle'] = "User Accounts";
    $data['view_module'] = "user_accounts";
    $data['tableTitle'] = "User Accounts";
    $data['view_file'] = 'manage';
    $this->load->module('template');
    $this->template->header($data);
    $this->template->sidebar($data);
    $this->template->footer($data);
}

function get($order_by)
{
    $this->load->model('user_accounts_m');
    $query = $this->user_accounts_m->get($order_by);
    return $query;
}

function get_with_limit($limit, $offset, $order_by)
{
    if ((!is_numeric($limit)) || (!is_numeric($offset))) {
        die('Non-numeric variable!');
    }

    $this->load->model('user_accounts_m');
    $query = $this->user_accounts_m->get_with_limit($limit, $offset, $order_by);
    return $query;
}

function get_with_double_condition($col1, $value1, $col2, $value2)
{
    $this->load->model('user_accounts_m');
    $query = $this->user_accounts_m->get_with_double_condition($col1, $value1, $col2, $value2);
    return $query;
}

function get_where($id)
{
    if (!is_numeric($id)) {
        die('Non-numeric variable!');
    }

    $this->load->model('user_accounts_m');
    $query = $this->user_accounts_m->get_where($id);
    return $query;
}

function get_where_custom($col, $value)
{
    $this->load->model('user_accounts_m');
    $query = $this->user_accounts_m->get_where_custom($col, $value);
    return $query;
}

function _insert($data)
{
    $this->load->model('user_accounts_m');
    $this->user_accounts_m->_insert($data);
}

function _update($id, $data)
{
    if (!is_numeric($id)) {
        die('Non-numeric variable!');
    }

    $this->load->model('user_accounts_m');
    $this->user_accounts_m->_update($id, $data);
}

function _delete($id)
{
    if (!is_numeric($id)) {
        die('Non-numeric variable!');
    }

    $this->load->model('user_accounts_m');
    $this->user_accounts_m->_delete($id);
}

function count_where($column, $value)
{
    $this->load->model('user_accounts_m');
    $count = $this->user_accounts_m->count_where($column, $value);
    return $count;
}

function get_max()
{
    $this->load->model('user_accounts_m');
    $max_id = $this->user_accounts_m->get_max();
    return $max_id;
}

function _custom_query($mysql_query)
{
    $this->load->model('user_accounts_m');
    $query = $this->user_accounts_m->_custom_query($mysql_query);
    return $query;
}

}
