<div class="row">
	<div class="col-md-12">
		<h1><?=$pageTitle?></h1>
		<?=validation_errors("<div class='alert alert-danger alert-bordered'>",
	"<button type='button' class='close' data-dismiss='alert'><span>×</span><span class='sr-only'>Close</span></button>
</div>"); ?>
<?php
if (isset($flash)){
	echo $flash;
}

 ?>
 <?php
 $form_location= base_url()."user_accounts/create/".$update_id;

  ?>
<?php $update_pword_url = base_url()."user_accounts/update_password/".$update_id; ?>
<?php $delete_user_url = base_url()."user_accounts/deleteconf"; ?>
	</div>
</div>
<div class="row mb-5">
	<div class="col-md-12">
		<div class="card">
			<div class="card-body">
				<div class="row">
					<div class="col-lg-12">

						<h3><div class="btn-group" role="group" aria-label="Basic example">
												<a href="<?=$update_pword_url?>"><button type="button" class="btn btn-warning waves-effect waves-light">Update Password</button></a>
												<button type="button" class="btn btn-danger waves-effect waves-light">Delete</button>
											</div></h3>
						<form method="post" action="<?=$form_location;?>">
							<div class="form-group row">
								<label for="inputEmail3" class="col-sm-2 col-form-label">Title</label>
								<div class="col-sm-10">
									<select name="initial" class="form-control" id="exampleFormControlSelect1">
									<option value="0">Please select</option>
									<option value="Mr">Mr</option>
									<option value="Mrs">Mrs</option>
									<option value="Ms">Ms</option>
									<option value="Dr">Dr</option>
								</select>
								</div>
							</div>
							<div class="form-group row">
								<label for="inputEmail3" class="col-sm-2 col-form-label">First Name</label>
								<div class="col-sm-10">
									<input type="text" name="firstname" class="form-control" value="<?=$firstname?>" id="inputEmail3" placeholder="">
								</div>
							</div>
							<div class="form-group row">
								<label for="inputPassword3" class="col-sm-2 col-form-label">Last Name</label>
								<div class="col-sm-10">
									<input type="text" name="lastname" class="form-control" value="<?=$lastname?>" id="inputPassword3" placeholder="">
								</div>
							</div>
							<div class="form-group row">
								<label for="inputPassword3" class="col-sm-2 col-form-label">Username</label>
								<div class="col-sm-10">
									<input type="text" name="username" class="form-control" value="<?=$username?>" id="inputPassword3" placeholder="">
								</div>
							</div>
							<div class="form-group row">
								<label for="inputPassword3" class="col-sm-2 col-form-label">Email</label>
								<div class="col-sm-10">
									<input type="email" name="email" class="form-control" value="<?=$email?>" id="inputPassword3" placeholder="">
								</div>
							</div>
							<div class="form-group row">
								<label for="inputPassword3" class="col-sm-2 col-form-label">Mobile Number</label>
								<div class="col-sm-10">
									<input type="text" name="telnum" class="form-control" value="<?=$telnum?>" id="inputPassword3" placeholder="">
								</div>
							</div>
							<div class="form-group row">
								<label for="inputEmail3" class="col-sm-2 col-form-label">Position Title</label>
								<div class="col-sm-10">
									<input type="text" name="title" class="form-control" value="<?=$title?>" id="inputEmail3" placeholder="">
								</div>
							</div>

							<div class="form-group row">
							<label for="inputPassword3" class="col-sm-2 col-form-label">Role</label>
							<div class="col-sm-10">
							<select name="role" class="form-control" id="exampleFormControlSelect1">
								<option value="0">Please Select</option>
								<option value="nematologist">Nematologist</option>
								<option value="pathologist">Pathologist</option>
								<option value="entomologist">Entomologist</option>
								<option value="technician">Technician</option>
								<option value="accounts">Accounts</option>
							</select>
							</div>
						</div>

							<div class="form-group row">
								<label for="inputPassword3" class="col-sm-2 col-form-label">Address Line 1</label>
								<div class="col-sm-10">
									<input type="text" name="address1" class="form-control" value="<?=$address1?>" id="inputPassword3" placeholder="">
								</div>
							</div>
							<div class="form-group row">
								<label for="inputPassword3" class="col-sm-2 col-form-label">Address Line 2</label>
								<div class="col-sm-10">
									<input type="text" name="address2" class="form-control" value="<?=$address2?>" id="inputPassword3" placeholder="">
								</div>
							</div>
							<div class="form-group row">
								<label for="inputPassword3" class="col-sm-2 col-form-label">Town</label>
								<div class="col-sm-10">
									<input type="text" name="town" class="form-control" value="<?=$town?>" id="inputPassword3" placeholder="">
								</div>
							</div>


							<div class="form-group row">
								<div class="col-sm-10">
									<button type="submit" name="submit" value="Submit" class="btn btn-primary">Submit</button>
								</div>
							</div>
						</form>
						<br>
						<br>


					</div>
				</div>
			</div>
		</div>
	</div>
</div>
