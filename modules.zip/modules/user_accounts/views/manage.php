<div class="row">
						<div class="col-md-12">
							<h1><?php echo $tableTitle; ?></h1>
							<?php $add_page_url = base_url()."user_accounts/create"; ?>
						</div>
					</div>
					<div class="row mb-5">
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="row">

										<div class="col-lg-12 pb-5">
											<h2><a href="<?=$add_page_url; ?>"><button id="btnGroupVerticalDrop2" type="button" class="btn btn-outline-success  waves-effect waves-light"  aria-haspopup="true" aria-expanded="false">
													Add User
												</button></a></h2>
										
											<div class="table-responsive">
												<table id="datatable-1" class="table table-datatable table-striped table-hover">
													<thead>
														<tr>
						                                    <th>FIRST NAME</th>
											                <th>LASTNAME</th>
											                <th>PHONE</th>
											                <th>ROLE</th>
											                <th>EMAIL</th>
											                <th>DATED CREATED</th>
						                                    <th>ACTION</th>
											            </tr>
													</thead>
													<tbody>
														 <?php 
														 $this->load->module('timedate');
														 foreach($query->result()  as $row) { 
															$edit_page_url = base_url()."user_accounts/create/".$row->id;
														 	$view_page_url = base_url()."user_accounts/individual/".$row->id;
														 	$delete_page_url = base_url()."user_accounts/deleteconf/".$row->id;
														 	$date_made = $this->timedate->get_nice_date($row->date_made, 'mini'); 
														 ?>
														<tr>
															<td><?php echo $row->firstname; ?></td>
															<td><?php echo $row->lastname; ?></td>
						                                    <td><?php echo $row->telnum; ?></td>
															<td><?php echo $row->role; ?></td>
															<td><?php echo $row->email; ?></td>
															<td><?php echo $date_made; ?></td>
						                                    
															<td>

																<span class="email-extra-icons">
																	<a href="<?= $edit_page_url;?>"><i class="batch-icon batch-icon-spam"></i></a>
																	<a href="<?= $delete_page_url;?>"><i style="color:red;" class="batch-icon batch-icon-bin-alt-2"></i></a>
																</span>
															</td>
														</tr>
													 <?php } ; ?>
													</tbody>
												</table>
											</div>
										</div>


									</div>
								</div>
							</div>
						</div>
					</div>
					

