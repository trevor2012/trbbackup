
<div class="row">
	<div class="col-md-12">
		<h1><?=$pageTitle?></h1>
		<?=validation_errors("<div class='alert alert-danger alert-bordered'>",
	"<button type='button' class='close' data-dismiss='alert'><span>×</span><span class='sr-only'>Close</span></button>
</div>"); ?>
<?php 
if (isset($flash)){
	echo $flash;
}

 ?>
<?php 
 $form_location= base_url()."user_accounts/update_password/".$update_id;

  ?>

	</div>
</div>
<div class="row mb-5">
	<div class="col-md-12">
		<div class="card">
			<div class="card-body">
				<div class="row">
					<div class="col-lg-12">
						<form method="post" action="<?=$form_location;?>">
							<div class="form-group row">
								<label for="inputEmail3" class="col-sm-2 col-form-label">Password</label>
								<div class="col-sm-10">
									<input type="text" name="pword" class="form-control" value="" id="inputEmail3" placeholder="">
								</div>
							</div>
							<div class="form-group row">
								<label for="inputPassword3" class="col-sm-2 col-form-label">Repeat Password</label>
								<div class="col-sm-10">
									<input type="text" name="repeat_pword" class="form-control" value="" id="inputPassword3" placeholder="">
								</div>
							</div>
							
							<div class="form-group row">
								<div class="col-sm-10">
									<button type="submit" name="submit" value="Submit" class="btn btn-primary">Submit</button>
								</div>
							</div>
						</form>
						<br>
						<br>

			
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
